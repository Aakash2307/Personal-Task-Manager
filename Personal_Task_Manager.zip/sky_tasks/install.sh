#!/usr/bin/env bash
# Sky Tasks – Ubuntu install script
set -e

echo "=== Sky Tasks Installer ==="

# Check Python
python3 --version >/dev/null 2>&1 || { echo "Python 3 required"; exit 1; }

# Create venv
python3 -m venv .venv
source .venv/bin/activate

# Install deps
pip install --upgrade pip
pip install -r requirements.txt

echo ""
echo "Installation complete."
echo ""
echo "To run Sky Tasks:"
echo "  source .venv/bin/activate && python main.py"
echo ""
echo "To enable autostart on login, run:"
echo "  python -c \"from app.utils.autostart import install_autostart; print(install_autostart())\""
