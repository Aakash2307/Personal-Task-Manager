"""Main window – sidebar + content stack."""
from __future__ import annotations
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QHBoxLayout, QVBoxLayout,
    QLabel, QPushButton, QFrame, QStackedWidget,
    QSystemTrayIcon, QMenu,
)
from PyQt6.QtCore import Qt, QTimer
from PyQt6.QtGui import QIcon, QPixmap, QColor, QAction, QKeySequence, QShortcut

from app.services.task_service import TaskService
from app.services.settings import SettingsService
from app.services.scheduler import SchedulerService
from app.services.notification import NotificationService
from app.ui.dashboard import DashboardView
from app.ui.tasks_view import TasksView
from app.ui.stats_view import StatsView
from app.ui.focus_window import FocusWindow
from app.ui.planning_window import PlanningWindow
from app.ui.weekly_review import WeeklyReviewWindow
from app.ui.settings_window import SettingsWindow


def _make_tray_icon() -> QIcon:
    """Generate a simple sky-blue square icon programmatically."""
    pix = QPixmap(32, 32)
    pix.fill(QColor("#4F8EF7"))
    return QIcon(pix)


class MainWindow(QMainWindow):
    def __init__(self, apply_theme_callback=None):
        super().__init__()
        self._apply_theme_callback = apply_theme_callback
        self._service = TaskService()
        self._scheduler = SchedulerService(self)
        self._notifier: NotificationService | None = None

        name = SettingsService.instance().get("user_name", "Sky")
        self.setWindowTitle(f"{name}'s Tasks")
        self.setMinimumSize(960, 640)
        self.resize(1100, 720)

        self._build_ui()
        self._build_tray()
        self._notifier = NotificationService(self._tray)
        self._connect_scheduler()
        self._scheduler.start()

        # Refresh timer – every 2 minutes
        self._refresh_timer = QTimer(self)
        self._refresh_timer.setInterval(120_000)
        self._refresh_timer.timeout.connect(self._refresh_current)
        self._refresh_timer.start()

        self._refresh_current()

    # ------------------------------------------------------------------ #
    # UI
    # ------------------------------------------------------------------ #

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # Content stack — must be created BEFORE sidebar (_nav references it)
        self._stack = QStackedWidget()
        self._stack.setObjectName("ContentArea")

        self._dashboard = DashboardView(self._service)
        self._tasks_view = TasksView(self._service)
        self._stats_view = StatsView(self._service)

        self._stack.addWidget(self._dashboard)   # 0
        self._stack.addWidget(self._tasks_view)  # 1
        self._stack.addWidget(self._stats_view)  # 2

        # Sidebar (calls _nav(0) internally, so stack must exist first)
        self._sidebar = self._make_sidebar()
        root.addWidget(self._sidebar)
        root.addWidget(self._stack, stretch=1)

        # Keyboard shortcuts
        QShortcut(QKeySequence("Ctrl+1"), self, lambda: self._nav(0))
        QShortcut(QKeySequence("Ctrl+2"), self, lambda: self._nav(1))
        QShortcut(QKeySequence("Ctrl+3"), self, lambda: self._nav(2))
        QShortcut(QKeySequence("Ctrl+N"), self, self._quick_new_task)

    def _make_sidebar(self) -> QWidget:
        sb = QWidget()
        sb.setObjectName("Sidebar")
        ly = QVBoxLayout(sb)
        ly.setContentsMargins(0, 0, 0, 0)
        ly.setSpacing(0)

        name = SettingsService.instance().get("user_name", "Sky").upper()
        title = QLabel(f"{name}'S TASKS")
        title.setObjectName("SidebarTitle")
        self._sidebar_title = title
        ly.addWidget(title)

        subtitle = QLabel("EXECUTION SYSTEM")
        subtitle.setObjectName("SidebarSubtitle")
        ly.addWidget(subtitle)

        sep = QFrame()
        sep.setFrameShape(QFrame.Shape.HLine)
        sep.setFixedHeight(1)
        ly.addWidget(sep)
        ly.addSpacing(8)

        self._nav_buttons: list[QPushButton] = []
        nav_items = [
            ("⊞  Dashboard", 0),
            ("☰  Tasks", 1),
            ("◎  Statistics", 2),
        ]
        for label, idx in nav_items:
            btn = QPushButton(label)
            btn.setObjectName("NavBtn")
            btn.clicked.connect(lambda checked=False, i=idx: self._nav(i))
            ly.addWidget(btn)
            self._nav_buttons.append(btn)

        ly.addSpacing(16)
        sep2 = QFrame()
        sep2.setFrameShape(QFrame.Shape.HLine)
        sep2.setFixedHeight(1)
        ly.addWidget(sep2)
        ly.addSpacing(8)

        focus_btn = QPushButton("☀  Focus Now")
        focus_btn.setObjectName("NavBtn")
        focus_btn.clicked.connect(self._show_focus)
        ly.addWidget(focus_btn)

        plan_btn = QPushButton("🌙  Plan Tomorrow")
        plan_btn.setObjectName("NavBtn")
        plan_btn.clicked.connect(self._show_planning)
        ly.addWidget(plan_btn)

        settings_btn = QPushButton("⚙  Settings")
        settings_btn.setObjectName("NavBtn")
        settings_btn.clicked.connect(self._show_settings)
        ly.addWidget(settings_btn)

        ly.addStretch()

        # Bottom status
        self._status_lbl = QLabel("Ready")
        self._status_lbl.setObjectName("TaskMeta")
        self._status_lbl.setContentsMargins(16, 0, 16, 16)
        self._status_lbl.setWordWrap(True)
        ly.addWidget(self._status_lbl)

        self._nav(0)
        return sb

    def _nav(self, idx: int):
        self._stack.setCurrentIndex(idx)
        for i, btn in enumerate(self._nav_buttons):
            btn.setProperty("active", "true" if i == idx else "false")
            btn.style().unpolish(btn)
            btn.style().polish(btn)
        self._refresh_current()

    # ------------------------------------------------------------------ #
    # Tray
    # ------------------------------------------------------------------ #

    def _build_tray(self):
        self._tray = QSystemTrayIcon(_make_tray_icon(), self)
        self._tray.setToolTip("Sky Tasks")
        menu = QMenu()

        menu.addAction("Open Dashboard", lambda: (self.show(), self.raise_(), self._nav(0)))
        menu.addAction("Open Tasks", lambda: (self.show(), self.raise_(), self._nav(1)))
        menu.addAction("Statistics", lambda: (self.show(), self.raise_(), self._nav(2)))
        menu.addSeparator()
        menu.addAction("☀ Focus Window", self._show_focus)
        menu.addAction("🌙 Plan Tomorrow", self._show_planning)
        menu.addSeparator()
        menu.addAction("⚙ Settings", self._show_settings)
        menu.addAction("Backup Now", self._manual_backup)
        menu.addSeparator()
        menu.addAction("Exit", self._quit)

        self._tray.setContextMenu(menu)
        self._tray.activated.connect(self._tray_activated)
        self._tray.show()

    def _tray_activated(self, reason):
        if reason == QSystemTrayIcon.ActivationReason.Trigger:
            if self.isVisible():
                self.hide()
            else:
                self.show()
                self.raise_()
                self._nav(0)

    # ------------------------------------------------------------------ #
    # Scheduler connections
    # ------------------------------------------------------------------ #

    def _connect_scheduler(self):
        s = self._scheduler
        s.focus_window_trigger.connect(self._on_focus_trigger)
        s.planning_window_trigger.connect(self._on_planning_trigger)
        s.weekly_review_trigger.connect(self._on_weekly_trigger)
        s.carry_forward_trigger.connect(self._on_carry_forward)
        s.backup_trigger.connect(self._on_backup)
        s.planning_reminder_trigger.connect(self._on_planning_reminder)

    def _on_focus_trigger(self):
        if self._notifier:
            self._notifier.notify(
                "Sky Tasks – Daily Focus",
                "Review today's execution list.",
                urgency="normal",
            )
        self._show_focus()

    def _on_planning_trigger(self):
        if self._notifier:
            self._notifier.notify(
                "Sky Tasks – Evening Planning",
                "Time to plan tomorrow intentionally.",
                urgency="normal",
            )
        self._show_planning()

    def _on_weekly_trigger(self):
        if self._notifier:
            self._notifier.notify(
                "Sky Tasks – Weekly Review",
                "Reflect on the week. What got done?",
                urgency="normal",
            )
        w = WeeklyReviewWindow(self._service, parent=self)
        w.review_done.connect(self._scheduler.mark_planning_done)
        w.show()

    def _on_carry_forward(self):
        self._service.carry_forward_tasks()
        self._refresh_current()

    def _on_backup(self):
        try:
            dest = self._service._db.backup()
            self._status_lbl.setText(f"Backup: {dest.name}")
        except Exception as e:
            self._status_lbl.setText(f"Backup failed: {e}")

    def _on_planning_reminder(self):
        if self._notifier:
            self._notifier.notify(
                "Sky Tasks – Planning Reminder",
                "You haven't planned tomorrow yet. Open planning window?",
                urgency="low",
            )

    # ------------------------------------------------------------------ #
    # Window helpers
    # ------------------------------------------------------------------ #

    def _show_focus(self):
        # Prevent multiple windows
        if hasattr(self, '_focus_win') and self._focus_win and self._focus_win.isVisible():
            self._focus_win.raise_()
            self._focus_win.activateWindow()
            return
        self._focus_win = FocusWindow(self._service, parent=self)
        self._focus_win.show()

    def _show_planning(self):
        # Prevent multiple windows
        if hasattr(self, '_plan_win') and self._plan_win and self._plan_win.isVisible():
            self._plan_win.raise_()
            self._plan_win.activateWindow()
            return
        self._plan_win = PlanningWindow(self._service, parent=self)
        self._plan_win.planning_done.connect(self._scheduler.mark_planning_done)
        self._plan_win.show()

    def _quick_new_task(self):
        from app.ui.task_editor import TaskEditorDialog
        dlg = TaskEditorDialog(self._service, parent=self)
        if dlg.exec():
            self._refresh_current()

    def _show_settings(self):
        dlg = SettingsWindow(parent=self)
        if dlg.exec():
            self._on_settings_changed()

    def _on_settings_changed(self):
        # Re-apply theme app-wide
        if self._apply_theme_callback:
            self._apply_theme_callback()

        # Update window title & sidebar name
        name = SettingsService.instance().get("user_name", "Sky")
        self.setWindowTitle(f"{name}'s Tasks")
        self._sidebar_title.setText(f"{name.upper()}'S TASKS")

        # Re-sync scheduler with new Focus/Planning times
        self._scheduler.reload_settings()

        self._refresh_current()

    def _manual_backup(self):
        try:
            dest = self._service._db.backup()
            if self._notifier:
                self._notifier.notify("Sky Tasks", f"Backup saved: {dest.name}")
        except Exception as e:
            if self._notifier:
                self._notifier.notify("Sky Tasks", f"Backup failed: {e}", "critical")

    # ------------------------------------------------------------------ #
    # Misc
    # ------------------------------------------------------------------ #

    def _refresh_current(self):
        idx = self._stack.currentIndex()
        views = [self._dashboard, self._tasks_view, self._stats_view]
        if idx < len(views):
            views[idx].refresh()

        stats = self._service.stats()
        overdue = stats["overdue"]
        pending = stats["pending"]
        self._status_lbl.setText(
            f"{pending} pending  ·  {overdue} overdue"
        )

    def closeEvent(self, event):
        # Minimise to tray instead of quitting
        event.ignore()
        self.hide()
        if self._notifier:
            self._notifier.notify(
                "Sky Tasks",
                "Still running in the system tray.",
                urgency="low",
            )

    def _quit(self):
        self._scheduler.stop()
        self._tray.hide()
        from PyQt6.QtWidgets import QApplication
        QApplication.quit()
