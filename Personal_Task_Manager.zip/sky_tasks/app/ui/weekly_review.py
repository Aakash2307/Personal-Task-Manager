"""Sunday Weekly Review Window."""
from __future__ import annotations
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QScrollArea, QWidget, QTabWidget,
)
from PyQt6.QtCore import Qt, pyqtSignal

from app.services.task_service import TaskService
from app.ui.widgets import TaskRow, StatCard, section_header


class WeeklyReviewWindow(QDialog):
    review_done = pyqtSignal()

    def __init__(self, service: TaskService, parent=None):
        super().__init__(parent)
        self._service = service
        self.setWindowTitle("📊 Sky Tasks – Weekly Review")
        self.setMinimumSize(700, 560)
        self.setModal(False)
        self.setWindowFlags(Qt.WindowType.Window | Qt.WindowType.WindowStaysOnTopHint)
        self._build()

    def _build(self):
        ly = QVBoxLayout(self)
        ly.setContentsMargins(28, 24, 28, 24)
        ly.setSpacing(0)

        title = QLabel("📊  Weekly Review")
        title.setObjectName("FocusTitle")
        ly.addWidget(title)

        sub = QLabel("Reflect on the week. Move unfinished work forward.")
        sub.setObjectName("TaskMeta")
        ly.addWidget(sub)
        ly.addSpacing(16)

        # Stats strip
        stats = self._service.stats()
        row = QHBoxLayout()
        row.setSpacing(12)
        for k, lbl in [
            ("completed_week", "Completed This Week"),
            ("pending", "Still Pending"),
            ("overdue", "Overdue"),
            ("completion_rate", "Completion Rate"),
        ]:
            v = stats.get(k, "—")
            if k == "completion_rate":
                v = f"{v}%"
            row.addWidget(StatCard(lbl, v))
        ly.addLayout(row)
        ly.addSpacing(16)

        tabs = QTabWidget()
        ly.addWidget(tabs, stretch=1)

        # Completed
        comp_w = QWidget()
        comp_ly = QVBoxLayout(comp_w)
        comp_ly.setContentsMargins(0, 8, 0, 0)
        scroll_c = QScrollArea()
        scroll_c.setWidgetResizable(True)
        scroll_c.setFrameShape(scroll_c.Shape.NoFrame)
        inner_c = QWidget()
        c_ly = QVBoxLayout(inner_c)
        c_ly.setContentsMargins(0, 0, 0, 0)
        for t in self._service.completed_this_week():
            row_w = TaskRow(t, show_complete_btn=False, parent=self)
            c_ly.addWidget(row_w)
        c_ly.addStretch()
        scroll_c.setWidget(inner_c)
        comp_ly.addWidget(scroll_c)
        tabs.addTab(comp_w, f"✓ Completed ({len(self._service.completed_this_week())})")

        # Unfinished
        pend_w = QWidget()
        pend_ly = QVBoxLayout(pend_w)
        pend_ly.setContentsMargins(0, 8, 0, 0)
        scroll_p = QScrollArea()
        scroll_p.setWidgetResizable(True)
        scroll_p.setFrameShape(scroll_p.Shape.NoFrame)
        inner_p = QWidget()
        self._pend_ly = QVBoxLayout(inner_p)
        self._pend_ly.setContentsMargins(0, 0, 0, 0)
        self._load_pending()
        scroll_p.setWidget(inner_p)
        pend_ly.addWidget(scroll_p)
        pending_count = len(self._service.pending_tasks())
        tabs.addTab(pend_w, f"⏳ Unfinished ({pending_count})")

        # Attention
        attn_w = QWidget()
        attn_ly = QVBoxLayout(attn_w)
        attn_ly.setContentsMargins(0, 8, 0, 0)
        scroll_a = QScrollArea()
        scroll_a.setWidgetResizable(True)
        scroll_a.setFrameShape(scroll_a.Shape.NoFrame)
        inner_a = QWidget()
        a_ly = QVBoxLayout(inner_a)
        a_ly.setContentsMargins(0, 0, 0, 0)
        for t in sorted(self._service.attention_tasks(), key=lambda x: x.age_days, reverse=True):
            row_w = TaskRow(t, parent=self)
            row_w.complete_clicked.connect(self._done)
            row_w.ack_clicked.connect(self._ack)
            a_ly.addWidget(row_w)
        a_ly.addStretch()
        scroll_a.setWidget(inner_a)
        attn_ly.addWidget(scroll_a)
        tabs.addTab(attn_w, f"⚠ Delayed ({len(self._service.attention_tasks())})")

        # Bottom
        bottom = QHBoxLayout()
        bottom.addStretch()
        close_btn = QPushButton("Complete Review ✓")
        close_btn.setObjectName("SuccessBtn")
        close_btn.clicked.connect(self._finish)
        bottom.addWidget(close_btn)
        ly.addSpacing(12)
        ly.addLayout(bottom)

    def _load_pending(self):
        while self._pend_ly.count():
            w = self._pend_ly.takeAt(0)
            if w.widget():
                w.widget().deleteLater()
        for t in self._service.pending_tasks():
            row = TaskRow(t, parent=self)
            row.complete_clicked.connect(self._done)
            row.edit_clicked.connect(self._edit)
            row.ack_clicked.connect(self._ack)
            self._pend_ly.addWidget(row)
        self._pend_ly.addStretch()

    def _done(self, tid):
        self._service.complete_task(tid)
        self._load_pending()

    def _edit(self, tid):
        task = self._service.get_task(tid)
        if task:
            from app.ui.task_editor import TaskEditorDialog
            dlg = TaskEditorDialog(self._service, task=task, parent=self)
            if dlg.exec():
                self._load_pending()

    def _ack(self, tid):
        self._service.acknowledge_task(tid)
        self._load_pending()

    def _finish(self):
        self.review_done.emit()
        self.accept()
