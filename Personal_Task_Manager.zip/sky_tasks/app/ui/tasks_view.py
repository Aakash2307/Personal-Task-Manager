"""Full task list with search & filter."""
from __future__ import annotations
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QLineEdit, QComboBox, QScrollArea,
)
from PyQt6.QtCore import Qt, QTimer

from app.models.task import Priority, Status
from app.services.task_service import TaskService
from app.ui.widgets import TaskRow, section_header
from app.ui.task_editor import TaskEditorDialog


class TasksView(QWidget):
    def __init__(self, service: TaskService, parent=None):
        super().__init__(parent)
        self._service = service
        self._search_timer = QTimer(self)
        self._search_timer.setSingleShot(True)
        self._search_timer.setInterval(250)
        self._search_timer.timeout.connect(self._apply_filter)
        self._build()

    def _build(self):
        ly = QVBoxLayout(self)
        ly.setContentsMargins(28, 24, 28, 24)
        ly.setSpacing(0)

        # Header
        hdr = QHBoxLayout()
        title = QLabel("All Tasks")
        title.setObjectName("PageTitle")
        hdr.addWidget(title)
        hdr.addStretch()
        new_btn = QPushButton("+ New Task")
        new_btn.setObjectName("PrimaryBtn")
        new_btn.clicked.connect(self._new_task)
        hdr.addWidget(new_btn)
        ly.addLayout(hdr)
        ly.addSpacing(16)

        # Filter bar
        filter_row = QHBoxLayout()
        filter_row.setSpacing(8)

        self._search = QLineEdit()
        self._search.setPlaceholderText("Search tasks…")
        self._search.textChanged.connect(lambda: self._search_timer.start())
        filter_row.addWidget(self._search, stretch=1)

        self._pri_filter = QComboBox()
        self._pri_filter.addItem("All Priorities", None)
        for p in Priority:
            self._pri_filter.addItem(p.value.capitalize(), p)
        self._pri_filter.currentIndexChanged.connect(self._apply_filter)
        filter_row.addWidget(self._pri_filter)

        self._status_filter = QComboBox()
        self._status_filter.addItem("All Statuses", None)
        for s in Status:
            self._status_filter.addItem(s.value.replace("_", " ").capitalize(), s)
        self._status_filter.currentIndexChanged.connect(self._apply_filter)
        filter_row.addWidget(self._status_filter)

        self._cat_filter = QComboBox()
        self._cat_filter.addItem("All Categories", None)
        self._cat_filter.currentIndexChanged.connect(self._apply_filter)
        filter_row.addWidget(self._cat_filter)

        ly.addLayout(filter_row)
        ly.addSpacing(16)

        # Task list
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(scroll.Shape.NoFrame)
        self._inner = QWidget()
        self._inner_ly = QVBoxLayout(self._inner)
        self._inner_ly.setContentsMargins(0, 0, 0, 0)
        self._inner_ly.setSpacing(4)
        scroll.setWidget(self._inner)
        ly.addWidget(scroll, stretch=1)

    def refresh(self):
        # Refresh category list
        self._cat_filter.clear()
        self._cat_filter.addItem("All Categories", None)
        for c in self._service.categories():
            self._cat_filter.addItem(c)
        self._apply_filter()

    def _apply_filter(self):
        query = self._search.text().strip()
        priority = self._pri_filter.currentData()
        status = self._status_filter.currentData()
        category = self._cat_filter.currentData()

        tasks = self._service.search(
            query=query,
            priority=priority,
            status=status,
            category=category,
        )

        while self._inner_ly.count():
            child = self._inner_ly.takeAt(0)
            if child.widget():
                child.widget().deleteLater()

        if not tasks:
            empty = QLabel("No tasks match your filter.")
            empty.setObjectName("TaskMeta")
            empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self._inner_ly.addWidget(empty)
        else:
            for t in tasks:
                row = TaskRow(t, parent=self)
                row.complete_clicked.connect(self._complete)
                row.edit_clicked.connect(self._edit)
                row.ack_clicked.connect(self._ack)
                self._inner_ly.addWidget(row)
        self._inner_ly.addStretch()

    def _new_task(self):
        dlg = TaskEditorDialog(self._service, parent=self)
        if dlg.exec():
            self.refresh()

    def _complete(self, task_id: int):
        self._service.complete_task(task_id)
        self._apply_filter()

    def _edit(self, task_id: int):
        task = self._service.get_task(task_id)
        if task:
            dlg = TaskEditorDialog(self._service, task=task, parent=self)
            if dlg.exec():
                self._apply_filter()

    def _ack(self, task_id: int):
        self._service.acknowledge_task(task_id)
        self._apply_filter()
