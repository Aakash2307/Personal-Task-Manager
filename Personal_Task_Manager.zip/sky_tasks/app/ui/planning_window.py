"""6 PM Planning Window – plan tomorrow intentionally."""
from __future__ import annotations
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QScrollArea, QWidget, QTabWidget,
)
from PyQt6.QtCore import Qt, pyqtSignal

from app.services.task_service import TaskService
from app.ui.widgets import TaskRow, section_header
from app.ui.task_editor import TaskEditorDialog


class PlanningWindow(QDialog):
    planning_done = pyqtSignal()

    def __init__(self, service: TaskService, parent=None):
        super().__init__(parent)
        self._service = service
        self.setWindowTitle("🌙 Sky Tasks – Evening Planning")
        self.setMinimumSize(680, 560)
        self.setModal(False)
        self.setWindowFlags(Qt.WindowType.Window | Qt.WindowType.WindowStaysOnTopHint)
        self._interacted = False
        self._build()

    def _build(self):
        ly = QVBoxLayout(self)
        ly.setContentsMargins(28, 24, 28, 24)
        ly.setSpacing(0)

        hdr = QHBoxLayout()
        title = QLabel("🌙  Evening Planning")
        title.setObjectName("FocusTitle")
        hdr.addWidget(title)
        hdr.addStretch()
        ly.addLayout(hdr)

        sub = QLabel("Plan tomorrow intentionally. What will you execute?")
        sub.setObjectName("TaskMeta")
        ly.addWidget(sub)
        ly.addSpacing(16)

        tabs = QTabWidget()
        ly.addWidget(tabs, stretch=1)

        # Tab 1: Pending tasks
        pending_w = QWidget()
        pending_ly = QVBoxLayout(pending_w)
        pending_ly.setContentsMargins(0, 8, 0, 0)
        scroll1 = QScrollArea()
        scroll1.setWidgetResizable(True)
        scroll1.setFrameShape(scroll1.Shape.NoFrame)
        inner1 = QWidget()
        self._pending_ly = QVBoxLayout(inner1)
        self._pending_ly.setContentsMargins(0, 0, 0, 0)
        scroll1.setWidget(inner1)
        pending_ly.addWidget(scroll1)
        tabs.addTab(pending_w, "Pending / Carry-Forward")

        # Tab 2: Add new
        new_w = QWidget()
        new_ly = QVBoxLayout(new_w)
        new_ly.setContentsMargins(0, 8, 0, 0)
        add_btn = QPushButton("+ Add New Task for Tomorrow")
        add_btn.setObjectName("PrimaryBtn")
        add_btn.clicked.connect(self._add_task)
        new_ly.addWidget(add_btn)
        new_ly.addStretch()
        tabs.addTab(new_w, "Add New Task")

        self._load_pending()

        # Bottom buttons
        bottom = QHBoxLayout()
        bottom.addStretch()
        skip_btn = QPushButton("Skip Planning Today")
        skip_btn.setObjectName("GhostBtn")
        skip_btn.clicked.connect(self._skip)
        done_btn = QPushButton("Done Planning ✓")
        done_btn.setObjectName("SuccessBtn")
        done_btn.clicked.connect(self._done)
        bottom.addWidget(skip_btn)
        bottom.addWidget(done_btn)
        ly.addSpacing(12)
        ly.addLayout(bottom)

    def _load_pending(self):
        while self._pending_ly.count():
            w = self._pending_ly.takeAt(0)
            if w.widget():
                w.widget().deleteLater()

        tasks = self._service.pending_tasks()
        overdue = self._service.overdue_tasks()
        carry = [t for t in tasks if t.carried_forward]

        for title, tlist in [
            ("🔴 Overdue", overdue),
            ("↩ Carry-Forward", carry),
            ("📋 Pending", [t for t in tasks if not t.carried_forward]),
        ]:
            if tlist:
                self._pending_ly.addWidget(section_header(title))
                for t in tlist:
                    row = TaskRow(t, parent=self)
                    row.complete_clicked.connect(self._mark_done)
                    row.edit_clicked.connect(self._edit)
                    row.ack_clicked.connect(self._ack)
                    self._pending_ly.addWidget(row)
                self._pending_ly.addSpacing(8)

        self._pending_ly.addStretch()

    def _add_task(self):
        dlg = TaskEditorDialog(self._service, parent=self)
        if dlg.exec():
            self._interacted = True
            self._load_pending()

    def _mark_done(self, tid):
        self._interacted = True
        self._service.complete_task(tid)
        self._load_pending()

    def _edit(self, tid):
        task = self._service.get_task(tid)
        if task:
            dlg = TaskEditorDialog(self._service, task=task, parent=self)
            if dlg.exec():
                self._interacted = True
                self._load_pending()

    def _ack(self, tid):
        self._service.acknowledge_task(tid)

    def _done(self):
        self._interacted = True
        self.planning_done.emit()
        self.accept()

    def _skip(self):
        self._interacted = True
        self.planning_done.emit()
        self.reject()

    def closeEvent(self, event):
        # Don't count as done if just closed
        super().closeEvent(event)
