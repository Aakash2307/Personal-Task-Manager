"""Reusable UI building blocks."""
from __future__ import annotations
from datetime import datetime
from PyQt6.QtWidgets import (
    QWidget, QHBoxLayout, QVBoxLayout, QLabel,
    QPushButton, QFrame, QSizePolicy,
)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QFont

from app.models.task import Task, Priority, Status


PRIORITY_LABELS = {
    Priority.CRITICAL: "CRITICAL",
    Priority.HIGH: "HIGH",
    Priority.MEDIUM: "MEDIUM",
    Priority.LOW: "LOW",
}


class PriorityBadge(QLabel):
    def __init__(self, priority: Priority, parent=None):
        super().__init__(PRIORITY_LABELS[priority], parent)
        self.setObjectName("PriBadge")
        self.setProperty("level", priority.value)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setFixedHeight(20)
        self.style().unpolish(self)
        self.style().polish(self)


class StatCard(QWidget):
    def __init__(self, label: str, value: str | int, parent=None):
        super().__init__(parent)
        self.setObjectName("StatCard")
        ly = QVBoxLayout(self)
        ly.setContentsMargins(16, 12, 16, 12)
        ly.setSpacing(4)

        self._value_lbl = QLabel(str(value))
        self._value_lbl.setObjectName("StatValue")
        lbl = QLabel(label.upper())
        lbl.setObjectName("StatLabel")

        ly.addWidget(self._value_lbl)
        ly.addWidget(lbl)

    def set_value(self, v):
        self._value_lbl.setText(str(v))


class TaskRow(QWidget):
    complete_clicked = pyqtSignal(int)
    edit_clicked = pyqtSignal(int)
    ack_clicked = pyqtSignal(int)

    def __init__(self, task: Task, show_complete_btn=True, parent=None):
        super().__init__(parent)
        self._task = task
        self.setObjectName("TaskRow")
        self.setProperty("attention", str(task.attention_level))
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._build(show_complete_btn)
        self.style().unpolish(self)
        self.style().polish(self)

    def _build(self, show_complete_btn: bool):
        outer = QHBoxLayout(self)
        outer.setContentsMargins(12, 10, 12, 10)
        outer.setSpacing(10)

        # Left: priority badge
        badge = PriorityBadge(self._task.priority)
        badge.setFixedWidth(62)
        outer.addWidget(badge)

        # Middle: title + meta
        mid = QVBoxLayout()
        mid.setSpacing(2)

        title_lbl = QLabel(self._task.title)
        title_lbl.setObjectName("TaskTitle")
        if self._task.status == Status.COMPLETED:
            title_lbl.setProperty("completed", "true")
        mid.addWidget(title_lbl)

        meta_parts = []
        if self._task.category:
            meta_parts.append(self._task.category)
        if self._task.due_date:
            due_str = self._task.due_date.strftime("%b %d %H:%M")
            meta_parts.append(f"Due {due_str}")
        if self._task.carry_count and self._task.carry_count > 0:
            meta_parts.append(f"Carried ×{self._task.carry_count}")

        meta = QLabel("  ·  ".join(meta_parts))
        meta.setObjectName("TaskMeta")
        mid.addWidget(meta)

        # Attention label
        attn = self._task.attention_level
        if attn == 1:
            a = QLabel(f"⚠ {self._task.age_days}d old")
            a.setObjectName("AgeWarn")
            mid.addWidget(a)
        elif attn == 2:
            a = QLabel(f"⚠ {self._task.age_days}d — escalated")
            a.setObjectName("AgeEsc")
            mid.addWidget(a)
        elif attn == 3:
            a = QLabel(f"🔴 {self._task.age_days}d — acknowledgement required")
            a.setObjectName("AgeAck")
            mid.addWidget(a)

        outer.addLayout(mid, stretch=1)

        # Right: action buttons
        btn_col = QVBoxLayout()
        btn_col.setSpacing(4)

        if self._task.attention_level == 3 and not self._task.acknowledged:
            ack_btn = QPushButton("Acknowledge")
            ack_btn.setObjectName("DangerBtn")
            ack_btn.setFixedHeight(26)
            ack_btn.clicked.connect(lambda: self.ack_clicked.emit(self._task.id))
            btn_col.addWidget(ack_btn)

        if show_complete_btn and self._task.status != Status.COMPLETED:
            done_btn = QPushButton("✓ Done")
            done_btn.setObjectName("SuccessBtn")
            done_btn.setFixedHeight(26)
            done_btn.clicked.connect(lambda: self.complete_clicked.emit(self._task.id))
            btn_col.addWidget(done_btn)

        edit_btn = QPushButton("Edit")
        edit_btn.setObjectName("GhostBtn")
        edit_btn.setFixedHeight(26)
        edit_btn.clicked.connect(lambda: self.edit_clicked.emit(self._task.id))
        btn_col.addWidget(edit_btn)

        outer.addLayout(btn_col)


def make_separator() -> QFrame:
    f = QFrame()
    f.setFrameShape(QFrame.Shape.HLine)
    f.setFixedHeight(1)
    return f


def section_header(text: str) -> QLabel:
    lbl = QLabel(text)
    lbl.setObjectName("SectionHeader")
    return lbl
