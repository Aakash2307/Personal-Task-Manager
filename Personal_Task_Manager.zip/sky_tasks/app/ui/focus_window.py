"""11 AM Focus Window – shows overdue, today's, critical tasks."""
from __future__ import annotations
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QScrollArea, QWidget,
)
from PyQt6.QtCore import Qt

from app.services.task_service import TaskService
from app.ui.widgets import TaskRow, section_header


class FocusWindow(QDialog):
    def __init__(self, service: TaskService, parent=None):
        super().__init__(parent)
        self._service = service
        self.setWindowTitle("☀ Sky's Tasks – Daily Focus")
        self.setObjectName("FocusWindow")
        self.setMinimumSize(600, 500)
        self.setModal(False)
        self.setWindowFlags(
            Qt.WindowType.Window |
            Qt.WindowType.WindowStaysOnTopHint
        )
        self._build()

    def _build(self):
        ly = QVBoxLayout(self)
        ly.setContentsMargins(28, 24, 28, 24)
        ly.setSpacing(0)

        # Header
        hdr = QHBoxLayout()
        title = QLabel("☀  Daily Focus")
        title.setObjectName("FocusTitle")
        hdr.addWidget(title)
        hdr.addStretch()
        close_btn = QPushButton("Dismiss")
        close_btn.setObjectName("GhostBtn")
        close_btn.clicked.connect(self.close)
        hdr.addWidget(close_btn)
        ly.addLayout(hdr)

        sub = QLabel("Review your execution list for today.")
        sub.setObjectName("TaskMeta")
        ly.addWidget(sub)
        ly.addSpacing(16)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(scroll.Shape.NoFrame)
        inner = QWidget()
        self._inner_ly = QVBoxLayout(inner)
        self._inner_ly.setContentsMargins(0, 0, 0, 0)
        self._inner_ly.setSpacing(4)
        scroll.setWidget(inner)
        ly.addWidget(scroll, stretch=1)

        self._load_tasks()

        ly.addSpacing(16)
        new_btn = QPushButton("+ Add Task")
        new_btn.setObjectName("PrimaryBtn")
        from app.ui.task_editor import TaskEditorDialog
        new_btn.clicked.connect(lambda: TaskEditorDialog(self._service, parent=self).exec() or self._reload())
        ly.addWidget(new_btn, alignment=Qt.AlignmentFlag.AlignRight)

    def _load_tasks(self):
        while self._inner_ly.count():
            w = self._inner_ly.takeAt(0)
            if w.widget():
                w.widget().deleteLater()

        overdue = self._service.overdue_tasks()
        critical = self._service.critical_tasks()
        today = self._service.todays_tasks()
        carry = [t for t in self._service.all_tasks() if t.carried_forward]

        sections = [
            ("🔴 Overdue", overdue),
            ("🚨 Critical", critical),
            ("📅 Today", today),
            ("↩ Carry-Forward", carry[:8]),
        ]
        any_task = False
        for title, tasks in sections:
            if tasks:
                any_task = True
                self._inner_ly.addWidget(section_header(title))
                for t in tasks:
                    row = TaskRow(t, parent=self)
                    row.complete_clicked.connect(self._done)
                    row.edit_clicked.connect(self._edit)
                    row.ack_clicked.connect(self._ack)
                    self._inner_ly.addWidget(row)
                self._inner_ly.addSpacing(10)

        if not any_task:
            self._inner_ly.addWidget(QLabel("🎉 All clear! No overdue or critical tasks."))
        self._inner_ly.addStretch()

    def _reload(self):
        self._load_tasks()

    def _done(self, tid):
        self._service.complete_task(tid)
        self._reload()

    def _edit(self, tid):
        task = self._service.get_task(tid)
        if task:
            from app.ui.task_editor import TaskEditorDialog
            dlg = TaskEditorDialog(self._service, task=task, parent=self)
            if dlg.exec():
                self._reload()

    def _ack(self, tid):
        self._service.acknowledge_task(tid)
        self._reload()
