STYLESHEET = """
/* ─────────────────────────────────────────────────────────────
   Sky Tasks  –  Dark mode stylesheet
   Palette:
     bg0  #0D0F12  (deepest background)
     bg1  #13161C  (main window)
     bg2  #1C2028  (panels, cards)
     bg3  #252B36  (inputs, hover)
     bg4  #2E3542  (borders, separators)
     acc  #4F8EF7  (electric blue accent)
     acc2 #7C5CF6  (violet secondary)
     txt0 #E8ECF4  (primary text)
     txt1 #9BA4B5  (secondary text)
     txt2 #5A6275  (muted text)
     ok   #3DCC91  (success / completed)
     warn #F5A623  (warning / 7-day)
     crit #E8445A  (critical / overdue / 14-day)
     hi   #FFD166  (highlight / 3-day)
───────────────────────────────────────────────────────────── */

* {
    font-family: "Inter", "Segoe UI", "Ubuntu", sans-serif;
    font-size: 13px;
    color: #E8ECF4;
}

QMainWindow, QDialog, QWidget {
    background-color: #13161C;
}

/* ── Sidebar ── */
#Sidebar {
    background-color: #0D0F12;
    border-right: 1px solid #2E3542;
    min-width: 200px;
    max-width: 200px;
}

#SidebarTitle {
    font-size: 18px;
    font-weight: 700;
    color: #4F8EF7;
    padding: 20px 16px 4px 16px;
    letter-spacing: 0.5px;
}

#SidebarSubtitle {
    font-size: 10px;
    color: #5A6275;
    padding: 0 16px 20px 16px;
    letter-spacing: 2px;
    text-transform: uppercase;
}

QPushButton#NavBtn {
    background: transparent;
    border: none;
    border-radius: 6px;
    padding: 10px 16px;
    text-align: left;
    color: #9BA4B5;
    font-size: 13px;
}
QPushButton#NavBtn:hover {
    background-color: #1C2028;
    color: #E8ECF4;
}
QPushButton#NavBtn[active="true"] {
    background-color: #1C2028;
    color: #4F8EF7;
    border-left: 3px solid #4F8EF7;
}

/* ── Content area ── */
#ContentArea {
    background-color: #13161C;
}

/* ── Cards / stat boxes ── */
#StatCard {
    background-color: #1C2028;
    border: 1px solid #2E3542;
    border-radius: 10px;
    padding: 16px;
}
#StatCard QLabel#StatValue {
    font-size: 28px;
    font-weight: 700;
    color: #4F8EF7;
}
#StatCard QLabel#StatLabel {
    font-size: 11px;
    color: #5A6275;
    text-transform: uppercase;
    letter-spacing: 1px;
}

/* ── Section headers ── */
QLabel#SectionHeader {
    font-size: 11px;
    font-weight: 600;
    color: #5A6275;
    letter-spacing: 2px;
    text-transform: uppercase;
    padding: 12px 0 6px 0;
}

QLabel#PageTitle {
    font-size: 22px;
    font-weight: 700;
    color: #E8ECF4;
    padding-bottom: 4px;
}

/* ── Task rows ── */
#TaskRow {
    background-color: #1C2028;
    border: 1px solid #2E3542;
    border-radius: 8px;
    margin: 3px 0;
    padding: 12px 14px;
}
#TaskRow:hover {
    border-color: #4F8EF7;
    background-color: #20262E;
}
#TaskRow[attention="1"] {
    border-left: 3px solid #FFD166;
}
#TaskRow[attention="2"] {
    border-left: 3px solid #F5A623;
}
#TaskRow[attention="3"] {
    border-left: 3px solid #E8445A;
    background-color: #21191D;
}

QLabel#TaskTitle {
    font-size: 14px;
    font-weight: 500;
    color: #E8ECF4;
}
QLabel#TaskMeta {
    font-size: 11px;
    color: #5A6275;
}
QLabel#TaskTitle[completed="true"] {
    color: #5A6275;
    text-decoration: line-through;
}

/* ── Priority badges ── */
QLabel#PriBadge {
    border-radius: 4px;
    padding: 2px 8px;
    font-size: 10px;
    font-weight: 700;
    letter-spacing: 1px;
}
QLabel#PriBadge[level="critical"] { background: #E8445A; color: #fff; }
QLabel#PriBadge[level="high"]     { background: #F5A623; color: #000; }
QLabel#PriBadge[level="medium"]   { background: #4F8EF7; color: #fff; }
QLabel#PriBadge[level="low"]      { background: #2E3542; color: #9BA4B5; }

/* ── Buttons ── */
QPushButton {
    background-color: #252B36;
    border: 1px solid #2E3542;
    border-radius: 6px;
    padding: 7px 16px;
    color: #E8ECF4;
    font-weight: 500;
}
QPushButton:hover { background-color: #2E3542; border-color: #4F8EF7; }
QPushButton:pressed { background-color: #1C2028; }

QPushButton#PrimaryBtn {
    background-color: #4F8EF7;
    border-color: #4F8EF7;
    color: #fff;
    font-weight: 600;
}
QPushButton#PrimaryBtn:hover { background-color: #6AA0F9; }
QPushButton#PrimaryBtn:pressed { background-color: #3A7BE8; }

QPushButton#DangerBtn {
    background-color: #E8445A;
    border-color: #E8445A;
    color: #fff;
}
QPushButton#DangerBtn:hover { background-color: #F0576A; }

QPushButton#SuccessBtn {
    background-color: #3DCC91;
    border-color: #3DCC91;
    color: #0D0F12;
    font-weight: 600;
}
QPushButton#SuccessBtn:hover { background-color: #52D8A0; }

QPushButton#GhostBtn {
    background: transparent;
    border-color: #2E3542;
    color: #9BA4B5;
}
QPushButton#GhostBtn:hover { border-color: #4F8EF7; color: #E8ECF4; }

/* ── Inputs ── */
QLineEdit, QTextEdit, QPlainTextEdit {
    background-color: #1C2028;
    border: 1px solid #2E3542;
    border-radius: 6px;
    padding: 8px 12px;
    color: #E8ECF4;
    selection-background-color: #4F8EF7;
}
QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus {
    border-color: #4F8EF7;
    background-color: #20262E;
}
QLineEdit::placeholder { color: #5A6275; }

QComboBox {
    background-color: #1C2028;
    border: 1px solid #2E3542;
    border-radius: 6px;
    padding: 7px 12px;
    color: #E8ECF4;
}
QComboBox:hover { border-color: #4F8EF7; }
QComboBox::drop-down { border: none; width: 24px; }
QComboBox::down-arrow { image: none; border: none; }
QComboBox QAbstractItemView {
    background-color: #1C2028;
    border: 1px solid #4F8EF7;
    selection-background-color: #252B36;
    color: #E8ECF4;
}

QDateTimeEdit {
    background-color: #1C2028;
    border: 1px solid #2E3542;
    border-radius: 6px;
    padding: 7px 12px;
    color: #E8ECF4;
}
QDateTimeEdit:hover { border-color: #4F8EF7; }

QSpinBox, QDoubleSpinBox {
    background-color: #1C2028;
    border: 1px solid #2E3542;
    border-radius: 6px;
    padding: 7px 12px;
    color: #E8ECF4;
}
QSpinBox:hover, QDoubleSpinBox:hover { border-color: #4F8EF7; }

/* ── ScrollBar ── */
QScrollBar:vertical {
    background: #13161C;
    width: 8px;
    margin: 0;
}
QScrollBar::handle:vertical {
    background: #2E3542;
    border-radius: 4px;
    min-height: 20px;
}
QScrollBar::handle:vertical:hover { background: #4F8EF7; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }

QScrollBar:horizontal {
    background: #13161C;
    height: 8px;
}
QScrollBar::handle:horizontal {
    background: #2E3542;
    border-radius: 4px;
    min-width: 20px;
}
QScrollBar::handle:horizontal:hover { background: #4F8EF7; }
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0; }

/* ── Tabs ── */
QTabWidget::pane {
    background: #1C2028;
    border: 1px solid #2E3542;
    border-radius: 8px;
    top: -1px;
}
QTabBar::tab {
    background: transparent;
    padding: 8px 20px;
    color: #9BA4B5;
    border-bottom: 2px solid transparent;
}
QTabBar::tab:selected {
    color: #4F8EF7;
    border-bottom: 2px solid #4F8EF7;
}
QTabBar::tab:hover { color: #E8ECF4; }

/* ── Progress bar ── */
QProgressBar {
    background-color: #252B36;
    border: none;
    border-radius: 4px;
    height: 6px;
    text-align: center;
}
QProgressBar::chunk {
    background-color: #4F8EF7;
    border-radius: 4px;
}

/* ── Separators ── */
QFrame[frameShape="4"], QFrame[frameShape="5"] {
    border: none;
    background-color: #2E3542;
    max-height: 1px;
}

/* ── Tooltips ── */
QToolTip {
    background-color: #252B36;
    color: #E8ECF4;
    border: 1px solid #4F8EF7;
    border-radius: 4px;
    padding: 4px 8px;
}

/* ── Focus window ── */
#FocusWindow {
    background-color: #0D0F12;
    border: 1px solid #4F8EF7;
    border-radius: 12px;
}
#FocusTitle {
    font-size: 20px;
    font-weight: 700;
    color: #4F8EF7;
    letter-spacing: 1px;
}

/* ── Attention badges ── */
QLabel#AgeWarn { color: #FFD166; font-size: 10px; font-weight: 600; }
QLabel#AgeEsc  { color: #F5A623; font-size: 10px; font-weight: 600; }
QLabel#AgeAck  { color: #E8445A; font-size: 10px; font-weight: 600; }

/* ── Checkboxes ── */
QCheckBox::indicator {
    width: 16px;
    height: 16px;
    border: 2px solid #2E3542;
    border-radius: 4px;
    background: #1C2028;
}
QCheckBox::indicator:checked {
    background: #4F8EF7;
    border-color: #4F8EF7;
}
QCheckBox::indicator:hover { border-color: #4F8EF7; }
"""
