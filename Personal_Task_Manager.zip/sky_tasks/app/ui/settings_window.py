"""Settings window — accessible anytime from sidebar/tray."""
from __future__ import annotations
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QLineEdit, QPushButton, QTimeEdit, QButtonGroup,
    QRadioButton, QScrollArea, QWidget, QFrame,
)
from PyQt6.QtCore import Qt, QTime, pyqtSignal

from app.services.settings import SettingsService
from app.ui.palette_picker import PalettePicker
from app.ui.widgets import section_header, make_separator


class SettingsWindow(QDialog):
    settings_changed = pyqtSignal()  # emitted when user saves

    def __init__(self, parent=None):
        super().__init__(parent)
        self._settings = SettingsService.instance()
        self.setWindowTitle("Settings")
        self.setMinimumSize(480, 600)
        self.setModal(True)
        self._build()

    def _build(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(28, 24, 28, 24)
        outer.setSpacing(16)

        title = QLabel("⚙  Settings")
        title.setObjectName("PageTitle")
        outer.addWidget(title)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(scroll.Shape.NoFrame)
        inner = QWidget()
        ly = QVBoxLayout(inner)
        ly.setSpacing(8)
        scroll.setWidget(inner)
        outer.addWidget(scroll, stretch=1)

        # ── Name ──────────────────────────────────────────────────────
        ly.addWidget(section_header("Your Name"))
        self._name_input = QLineEdit(self._settings.get("user_name", "Sky"))
        self._name_input.setFixedHeight(38)
        ly.addWidget(self._name_input)
        ly.addSpacing(12)

        # ── Appearance: Light/Dark ───────────────────────────────────
        ly.addWidget(section_header("Appearance"))
        mode_row = QHBoxLayout()
        self._mode_group = QButtonGroup(self)
        self._dark_radio = QRadioButton("🌙  Dark Mode")
        self._light_radio = QRadioButton("☀  Light Mode")
        self._mode_group.addButton(self._dark_radio)
        self._mode_group.addButton(self._light_radio)
        mode_row.addWidget(self._dark_radio)
        mode_row.addWidget(self._light_radio)
        mode_row.addStretch()
        ly.addLayout(mode_row)

        current_mode = self._settings.get("theme_mode", "dark")
        if current_mode == "dark":
            self._dark_radio.setChecked(True)
        else:
            self._light_radio.setChecked(True)
        ly.addSpacing(12)

        # ── Color Palette ─────────────────────────────────────────────
        ly.addWidget(section_header("Color Palette"))
        self._palette_picker = PalettePicker(
            current_palette=self._settings.get("palette_id", "sky_blue"),
            custom_hex=self._settings.get("custom_color"),
            parent=self,
        )
        ly.addWidget(self._palette_picker)
        ly.addSpacing(12)

        # ── Focus / Planning times ──────────────────────────────────
        ly.addWidget(section_header("Daily Focus Window Time"))
        self._focus_time = QTimeEdit()
        self._focus_time.setDisplayFormat("hh:mm AP")
        self._focus_time.setTime(QTime(
            self._settings.get("focus_hour", 11),
            self._settings.get("focus_minute", 0),
        ))
        ly.addWidget(self._focus_time)
        ly.addSpacing(8)

        ly.addWidget(section_header("Evening Planning Window Time"))
        self._planning_time = QTimeEdit()
        self._planning_time.setDisplayFormat("hh:mm AP")
        self._planning_time.setTime(QTime(
            self._settings.get("planning_hour", 18),
            self._settings.get("planning_minute", 0),
        ))
        ly.addWidget(self._planning_time)
        ly.addSpacing(20)

        # ── Buttons ──────────────────────────────────────────────────
        btn_row = QHBoxLayout()
        btn_row.addStretch()
        cancel = QPushButton("Cancel")
        cancel.setObjectName("GhostBtn")
        cancel.clicked.connect(self.reject)
        save = QPushButton("Save Settings")
        save.setObjectName("PrimaryBtn")
        save.clicked.connect(self._save)
        btn_row.addWidget(cancel)
        btn_row.addWidget(save)
        outer.addLayout(btn_row)

    def _save(self):
        name = self._name_input.text().strip() or "Sky"
        mode = "dark" if self._dark_radio.isChecked() else "light"
        palette_id = self._palette_picker._current
        custom_hex = self._palette_picker._custom_hex if palette_id == "custom" else None

        ft = self._focus_time.time()
        pt = self._planning_time.time()

        self._settings.set_many(
            user_name=name,
            theme_mode=mode,
            palette_id=palette_id,
            custom_color=custom_hex,
            focus_hour=ft.hour(),
            focus_minute=ft.minute(),
            planning_hour=pt.hour(),
            planning_minute=pt.minute(),
        )

        self.settings_changed.emit()
        self.accept()
