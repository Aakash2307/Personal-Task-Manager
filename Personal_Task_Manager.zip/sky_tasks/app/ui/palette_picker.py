"""Reusable color palette picker widget."""
from __future__ import annotations
from PyQt6.QtWidgets import (
    QWidget, QHBoxLayout, QVBoxLayout, QPushButton,
    QLabel, QColorDialog, QButtonGroup,
)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QColor

from app.ui.themes import PRESET_PALETTES


class SwatchButton(QPushButton):
    def __init__(self, palette_id: str, color: str, parent=None):
        super().__init__(parent)
        self.palette_id = palette_id
        self.setObjectName("PaletteSwatch")
        self.setFixedSize(40, 40)
        self.setCheckable(True)
        self.setStyleSheet(
            f"background-color: {color}; border-radius: 8px;"
        )
        self.setProperty("selected", "false")

    def set_selected(self, selected: bool):
        self.setProperty("selected", "true" if selected else "false")
        self.style().unpolish(self)
        self.style().polish(self)


class PalettePicker(QWidget):
    palette_changed = pyqtSignal(str, str)  # palette_id, custom_hex_or_empty

    def __init__(self, current_palette: str = "sky_blue", custom_hex: str | None = None, parent=None):
        super().__init__(parent)
        self._current = current_palette
        self._custom_hex = custom_hex or "#4F8EF7"
        self._swatches: dict[str, SwatchButton] = {}
        self._build()

    def _build(self):
        ly = QVBoxLayout(self)
        ly.setContentsMargins(0, 0, 0, 0)
        ly.setSpacing(10)

        grid = QHBoxLayout()
        grid.setSpacing(8)

        for pid, info in PRESET_PALETTES.items():
            btn = SwatchButton(pid, info["accent"])
            btn.setToolTip(info["label"])
            btn.clicked.connect(lambda checked=False, p=pid: self._select(p))
            self._swatches[pid] = btn
            grid.addWidget(btn)

        # Custom swatch
        self._custom_btn = SwatchButton("custom", self._custom_hex)
        self._custom_btn.setToolTip("Custom color…")
        self._custom_btn.clicked.connect(self._pick_custom)
        self._swatches["custom"] = self._custom_btn
        grid.addWidget(self._custom_btn)

        grid.addStretch()
        ly.addLayout(grid)

        self._label = QLabel(self._current_label())
        self._label.setObjectName("TaskMeta")
        ly.addWidget(self._label)

        self._refresh_selection()

    def _current_label(self) -> str:
        if self._current == "custom":
            return f"Custom — {self._custom_hex}"
        return PRESET_PALETTES.get(self._current, {}).get("label", self._current)

    def _select(self, palette_id: str):
        self._current = palette_id
        self._refresh_selection()
        self._label.setText(self._current_label())
        self.palette_changed.emit(self._current, self._custom_hex if palette_id == "custom" else "")

    def _pick_custom(self):
        color = QColorDialog.getColor(QColor(self._custom_hex), self, "Pick a color")
        if color.isValid():
            self._custom_hex = color.name()
            self._custom_btn.setStyleSheet(f"background-color: {self._custom_hex}; border-radius: 8px;")
            self._select("custom")

    def _refresh_selection(self):
        for pid, btn in self._swatches.items():
            btn.set_selected(pid == self._current)
            btn.setChecked(pid == self._current)
