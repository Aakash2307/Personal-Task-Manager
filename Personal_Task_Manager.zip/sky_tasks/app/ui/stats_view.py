"""Statistics panel."""
from __future__ import annotations
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QProgressBar,
)
from PyQt6.QtCore import Qt

from app.services.task_service import TaskService
from app.ui.widgets import StatCard, section_header


class StatsView(QWidget):
    def __init__(self, service: TaskService, parent=None):
        super().__init__(parent)
        self._service = service
        self._build()

    def _build(self):
        ly = QVBoxLayout(self)
        ly.setContentsMargins(28, 24, 28, 24)
        ly.setSpacing(0)

        title = QLabel("Statistics")
        title.setObjectName("PageTitle")
        ly.addWidget(title)
        ly.addSpacing(20)

        # Top row
        row1 = QHBoxLayout()
        row1.setSpacing(12)
        self._cards: dict[str, StatCard] = {}
        for k, lbl in [
            ("completed_today", "Done Today"),
            ("completed_week", "Done This Week"),
            ("completed_month", "Done This Month"),
            ("avg_completion_hours", "Avg Completion (hrs)"),
        ]:
            c = StatCard(lbl, "—")
            self._cards[k] = c
            row1.addWidget(c)
        ly.addLayout(row1)
        ly.addSpacing(24)

        ly.addWidget(section_header("Completion Rate"))

        self._rate_bar = QProgressBar()
        self._rate_bar.setRange(0, 100)
        self._rate_bar.setFixedHeight(14)
        ly.addWidget(self._rate_bar)

        self._rate_lbl = QLabel("—")
        self._rate_lbl.setObjectName("TaskMeta")
        ly.addWidget(self._rate_lbl)
        ly.addSpacing(20)

        ly.addWidget(section_header("Attention Required"))
        self._attention_lbl = QLabel("—")
        self._attention_lbl.setWordWrap(True)
        ly.addWidget(self._attention_lbl)

        ly.addStretch()

    def refresh(self):
        stats = self._service.stats()
        for k in ("completed_today", "completed_week", "completed_month", "avg_completion_hours"):
            if k in self._cards:
                self._cards[k].set_value(stats.get(k, "—"))

        rate = stats.get("completion_rate", 0)
        self._rate_bar.setValue(int(rate))
        self._rate_lbl.setText(
            f"{rate}% of tasks in the pipeline completed this month"
        )

        attn = self._service.attention_tasks()
        if attn:
            msgs = []
            for t in attn[:5]:
                level_map = {1: "⚠ Highlight", 2: "🔶 Warning", 3: "🔴 Ack Required"}
                msgs.append(f"{level_map.get(t.attention_level, '')}  –  {t.title}")
            self._attention_lbl.setText("\n".join(msgs))
        else:
            self._attention_lbl.setText("All tasks within normal age range. ✓")
