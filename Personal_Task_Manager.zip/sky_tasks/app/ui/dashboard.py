"""Main dashboard panel."""
from __future__ import annotations
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QScrollArea,
    QLabel, QPushButton,
)
from PyQt6.QtCore import Qt

from app.services.task_service import TaskService
from app.services.settings import SettingsService
from app.ui.widgets import StatCard, TaskRow, section_header, make_separator
from app.ui.task_editor import TaskEditorDialog


class DashboardView(QWidget):
    def __init__(self, service: TaskService, parent=None):
        super().__init__(parent)
        self._service = service
        self._build()

    def _build(self):
        ly = QVBoxLayout(self)
        ly.setContentsMargins(28, 24, 28, 24)
        ly.setSpacing(0)

        # Header
        hdr = QHBoxLayout()
        name = SettingsService.instance().get("user_name", "My")
        title = QLabel(f"{name}'s Task Manager")
        title.setObjectName("PageTitle")
        self._title_lbl = title
        hdr.addWidget(title)
        hdr.addStretch()
        new_btn = QPushButton("+ New Task")
        new_btn.setObjectName("PrimaryBtn")
        new_btn.clicked.connect(self._new_task)
        hdr.addWidget(new_btn)
        ly.addLayout(hdr)
        ly.addSpacing(20)

        # Stat cards row
        self._stat_row = QHBoxLayout()
        self._stat_row.setSpacing(12)
        self._cards: dict[str, StatCard] = {}
        for key, label in [
            ("completed_today", "Done Today"),
            ("completed_week", "Done This Week"),
            ("overdue", "Overdue"),
            ("completion_rate", "Completion Rate"),
        ]:
            card = StatCard(label, "—")
            self._cards[key] = card
            self._stat_row.addWidget(card)
        ly.addLayout(self._stat_row)
        ly.addSpacing(24)

        # Scrollable task sections
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(scroll.Shape.NoFrame)
        inner = QWidget()
        self._inner_ly = QVBoxLayout(inner)
        self._inner_ly.setContentsMargins(0, 0, 0, 0)
        self._inner_ly.setSpacing(0)
        scroll.setWidget(inner)
        ly.addWidget(scroll, stretch=1)

    def refresh(self):
        name = SettingsService.instance().get("user_name", "My")
        self._title_lbl.setText(f"{name}'s Task Manager")

        stats = self._service.stats()
        self._cards["completed_today"].set_value(stats["completed_today"])
        self._cards["completed_week"].set_value(stats["completed_week"])
        self._cards["overdue"].set_value(stats["overdue"])
        self._cards["completion_rate"].set_value(f"{stats['completion_rate']}%")

        # Rebuild task sections
        while self._inner_ly.count():
            child = self._inner_ly.takeAt(0)
            if child.widget():
                child.widget().deleteLater()

        self._render_section("🔴 Overdue", self._service.overdue_tasks())
        self._render_section("📌 Critical", self._service.critical_tasks())
        self._render_section("📅 Today", self._service.todays_tasks())
        self._render_section("🕐 All Pending", self._service.pending_tasks()[:10])
        self._inner_ly.addStretch()

    def _render_section(self, title: str, tasks):
        if not tasks:
            return
        self._inner_ly.addWidget(section_header(title))
        for t in tasks:
            row = TaskRow(t, parent=self)
            row.complete_clicked.connect(self._complete_task)
            row.edit_clicked.connect(self._edit_task)
            row.ack_clicked.connect(self._ack_task)
            self._inner_ly.addWidget(row)
        self._inner_ly.addSpacing(12)

    def _new_task(self):
        dlg = TaskEditorDialog(self._service, parent=self)
        if dlg.exec():
            self.refresh()

    def _complete_task(self, task_id: int):
        self._service.complete_task(task_id)
        self.refresh()

    def _edit_task(self, task_id: int):
        task = self._service.get_task(task_id)
        if task:
            dlg = TaskEditorDialog(self._service, task=task, parent=self)
            if dlg.exec():
                self.refresh()

    def _ack_task(self, task_id: int):
        self._service.acknowledge_task(task_id)
        self.refresh()
