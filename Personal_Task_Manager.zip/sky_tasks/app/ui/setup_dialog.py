"""First-run setup dialog — name, theme, palette, and schedule times."""
from __future__ import annotations
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QLineEdit, QPushButton, QTimeEdit, QButtonGroup,
    QRadioButton, QStackedWidget, QWidget,
)
from PyQt6.QtCore import Qt, QTime

from app.services.settings import SettingsService
from app.ui.palette_picker import PalettePicker
from app.ui.widgets import section_header


class SetupDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._settings = SettingsService.instance()
        self.setWindowTitle("Welcome to Sky Tasks")
        self.setFixedSize(480, 560)
        self.setModal(True)
        self.setWindowFlags(
            Qt.WindowType.Dialog |
            Qt.WindowType.CustomizeWindowHint |
            Qt.WindowType.WindowTitleHint
        )
        self._step = 0
        self._build()

    def _build(self):
        ly = QVBoxLayout(self)
        ly.setContentsMargins(36, 32, 36, 32)
        ly.setSpacing(16)

        title = QLabel("👋  Welcome to Sky Tasks")
        title.setObjectName("FocusTitle")
        ly.addWidget(title)

        sub = QLabel("Let's set things up the way you like.")
        sub.setObjectName("TaskMeta")
        ly.addWidget(sub)
        ly.addSpacing(8)

        self._stack = QStackedWidget()
        ly.addWidget(self._stack, stretch=1)

        self._stack.addWidget(self._build_step_name())
        self._stack.addWidget(self._build_step_theme())
        self._stack.addWidget(self._build_step_times())

        self._error_lbl = QLabel("")
        self._error_lbl.setStyleSheet("color: #E8445A; font-size: 11px;")
        ly.addWidget(self._error_lbl)

        # Nav buttons
        nav = QHBoxLayout()
        self._back_btn = QPushButton("← Back")
        self._back_btn.setObjectName("GhostBtn")
        self._back_btn.clicked.connect(self._go_back)
        self._back_btn.setVisible(False)
        nav.addWidget(self._back_btn)
        nav.addStretch()
        self._next_btn = QPushButton("Next →")
        self._next_btn.setObjectName("PrimaryBtn")
        self._next_btn.clicked.connect(self._go_next)
        nav.addWidget(self._next_btn)
        ly.addLayout(nav)

    # ── Step 1: Name ─────────────────────────────────────────────────
    def _build_step_name(self) -> QWidget:
        w = QWidget()
        ly = QVBoxLayout(w)
        ly.setContentsMargins(0, 0, 0, 0)
        ly.addWidget(section_header("What's your name?"))
        self._name_input = QLineEdit()
        self._name_input.setPlaceholderText("Enter your first name…")
        self._name_input.setFixedHeight(40)
        self._name_input.returnPressed.connect(self._go_next)
        ly.addWidget(self._name_input)
        ly.addStretch()
        return w

    # ── Step 2: Theme + palette ─────────────────────────────────────
    def _build_step_theme(self) -> QWidget:
        w = QWidget()
        ly = QVBoxLayout(w)
        ly.setContentsMargins(0, 0, 0, 0)
        ly.setSpacing(12)

        ly.addWidget(section_header("Appearance"))
        mode_row = QHBoxLayout()
        self._mode_group = QButtonGroup(self)
        self._dark_radio = QRadioButton("🌙  Dark Mode")
        self._light_radio = QRadioButton("☀  Light Mode")
        self._dark_radio.setChecked(True)
        self._mode_group.addButton(self._dark_radio)
        self._mode_group.addButton(self._light_radio)
        mode_row.addWidget(self._dark_radio)
        mode_row.addWidget(self._light_radio)
        mode_row.addStretch()
        ly.addLayout(mode_row)
        ly.addSpacing(8)

        ly.addWidget(section_header("Pick Your Color"))
        self._palette_picker = PalettePicker(parent=self)
        ly.addWidget(self._palette_picker)
        ly.addStretch()
        return w

    # ── Step 3: Times ───────────────────────────────────────────────
    def _build_step_times(self) -> QWidget:
        w = QWidget()
        ly = QVBoxLayout(w)
        ly.setContentsMargins(0, 0, 0, 0)
        ly.setSpacing(10)

        ly.addWidget(section_header("☀  When should your Focus Window appear?"))
        self._focus_time = QTimeEdit()
        self._focus_time.setDisplayFormat("hh:mm AP")
        self._focus_time.setTime(QTime(11, 0))
        ly.addWidget(self._focus_time)
        ly.addSpacing(12)

        ly.addWidget(section_header("🌙  When should your Planning Window appear?"))
        self._planning_time = QTimeEdit()
        self._planning_time.setDisplayFormat("hh:mm AP")
        self._planning_time.setTime(QTime(18, 0))
        ly.addWidget(self._planning_time)

        note = QLabel("You can change all of this anytime in Settings.")
        note.setObjectName("TaskMeta")
        note.setWordWrap(True)
        ly.addSpacing(16)
        ly.addWidget(note)
        ly.addStretch()
        return w

    # ── Navigation ───────────────────────────────────────────────────
    def _go_next(self):
        if self._step == 0:
            if not self._name_input.text().strip():
                self._error_lbl.setText("Please enter your name to continue.")
                self._name_input.setFocus()
                return
        self._error_lbl.setText("")

        if self._step < self._stack.count() - 1:
            self._step += 1
            self._stack.setCurrentIndex(self._step)
            self._back_btn.setVisible(True)
            if self._step == self._stack.count() - 1:
                self._next_btn.setText("Get Started →")
        else:
            self._finish()

    def _go_back(self):
        if self._step > 0:
            self._step -= 1
            self._stack.setCurrentIndex(self._step)
            self._back_btn.setVisible(self._step > 0)
            self._next_btn.setText("Next →")

    def _finish(self):
        name = self._name_input.text().strip()
        mode = "dark" if self._dark_radio.isChecked() else "light"
        palette_id = self._palette_picker._current
        custom_hex = self._palette_picker._custom_hex if palette_id == "custom" else None
        ft = self._focus_time.time()
        pt = self._planning_time.time()

        self._settings.set_many(
            user_name=name,
            theme_mode=mode,
            palette_id=palette_id,
            custom_color=custom_hex,
            focus_hour=ft.hour(),
            focus_minute=ft.minute(),
            planning_hour=pt.hour(),
            planning_minute=pt.minute(),
            setup_complete=True,
        )
        self.accept()

    def closeEvent(self, event):
        event.ignore()
