"""
Sky Tasks – Theme & Palette System
Generates a QSS stylesheet dynamically based on chosen palette + mode (dark/light).
"""
from __future__ import annotations

# ── Preset Palettes ────────────────────────────────────────────────────────
# Each palette defines an "accent" and "accent2" color.
# Dark/light base colors stay consistent; only accents change.

PRESET_PALETTES = {
    "sky_blue":  {"label": "Sky Blue",   "accent": "#4F8EF7", "accent2": "#7C5CF6"},
    "rose_pink": {"label": "Rose Pink",  "accent": "#F75C9C", "accent2": "#F7A6C4"},
    "violet":    {"label": "Violet",     "accent": "#9B6CF7", "accent2": "#C49CF7"},
    "emerald":   {"label": "Emerald",    "accent": "#3DCC91", "accent2": "#6CE8B5"},
    "amber":     {"label": "Amber",      "accent": "#F5A623", "accent2": "#F7C873"},
    "crimson":   {"label": "Crimson",    "accent": "#E8445A", "accent2": "#F77C8E"},
    "teal":      {"label": "Teal",       "accent": "#22C3C3", "accent2": "#7DE8E8"},
    "slate":     {"label": "Slate",      "accent": "#6C8EBF", "accent2": "#9BB3D9"},
}

DEFAULT_PALETTE = "sky_blue"


def get_accent(palette_id: str, custom_hex: str | None = None) -> tuple[str, str]:
    """Returns (accent, accent2) hex colors."""
    if palette_id == "custom" and custom_hex:
        return custom_hex, _lighten(custom_hex, 0.25)
    p = PRESET_PALETTES.get(palette_id, PRESET_PALETTES[DEFAULT_PALETTE])
    return p["accent"], p["accent2"]


def _lighten(hex_color: str, amount: float) -> str:
    """Lighten a hex color by blending toward white."""
    hex_color = hex_color.lstrip("#")
    r, g, b = int(hex_color[0:2], 16), int(hex_color[2:4], 16), int(hex_color[4:6], 16)
    r = int(r + (255 - r) * amount)
    g = int(g + (255 - g) * amount)
    b = int(b + (255 - b) * amount)
    return f"#{r:02x}{g:02x}{b:02x}"


def _darken(hex_color: str, amount: float) -> str:
    hex_color = hex_color.lstrip("#")
    r, g, b = int(hex_color[0:2], 16), int(hex_color[2:4], 16), int(hex_color[4:6], 16)
    r = int(r * (1 - amount))
    g = int(g * (1 - amount))
    b = int(b * (1 - amount))
    return f"#{r:02x}{g:02x}{b:02x}"


# ── Base color schemes ────────────────────────────────────────────────────

DARK_BASE = {
    "bg0": "#0D0F12", "bg1": "#13161C", "bg2": "#1C2028",
    "bg3": "#252B36", "bg4": "#2E3542",
    "txt0": "#E8ECF4", "txt1": "#9BA4B5", "txt2": "#5A6275",
    "ok": "#3DCC91", "warn": "#F5A623", "crit": "#E8445A", "hi": "#FFD166",
}

LIGHT_BASE = {
    "bg0": "#FFFFFF", "bg1": "#F7F8FA", "bg2": "#FFFFFF",
    "bg3": "#F0F2F5", "bg4": "#DDE2EA",
    "txt0": "#1A1D24", "txt1": "#5A6275", "txt2": "#9BA4B5",
    "ok": "#1F9D6C", "warn": "#C97E0A", "crit": "#D32F4A", "hi": "#B8860B",
}


def generate_stylesheet(mode: str = "dark", palette_id: str = DEFAULT_PALETTE, custom_hex: str | None = None) -> str:
    """Generate the full QSS stylesheet for the given mode + palette."""
    base = DARK_BASE if mode == "dark" else LIGHT_BASE
    accent, accent2 = get_accent(palette_id, custom_hex)

    c = {**base, "acc": accent, "acc2": accent2}

    # Text-on-accent: use dark text if accent is light, else white
    acc_text = "#0D0F12" if _is_light(accent) else "#FFFFFF"

    return f"""
* {{
    font-family: "Inter", "Segoe UI", "Ubuntu", sans-serif;
    font-size: 13px;
    color: {c['txt0']};
}}

QMainWindow, QDialog, QWidget {{
    background-color: {c['bg1']};
}}

#Sidebar {{
    background-color: {c['bg0']};
    border-right: 1px solid {c['bg4']};
    min-width: 200px;
    max-width: 200px;
}}

#SidebarTitle {{
    font-size: 18px;
    font-weight: 700;
    color: {c['acc']};
    padding: 20px 16px 4px 16px;
    letter-spacing: 0.5px;
}}

#SidebarSubtitle {{
    font-size: 10px;
    color: {c['txt2']};
    padding: 0 16px 20px 16px;
    letter-spacing: 2px;
    text-transform: uppercase;
}}

QPushButton#NavBtn {{
    background: transparent;
    border: none;
    border-radius: 6px;
    padding: 10px 16px;
    text-align: left;
    color: {c['txt1']};
    font-size: 13px;
}}
QPushButton#NavBtn:hover {{
    background-color: {c['bg2']};
    color: {c['txt0']};
}}
QPushButton#NavBtn[active="true"] {{
    background-color: {c['bg2']};
    color: {c['acc']};
    border-left: 3px solid {c['acc']};
}}

#ContentArea {{ background-color: {c['bg1']}; }}

#StatCard {{
    background-color: {c['bg2']};
    border: 1px solid {c['bg4']};
    border-radius: 10px;
    padding: 16px;
}}
#StatCard QLabel#StatValue {{ font-size: 28px; font-weight: 700; color: {c['acc']}; }}
#StatCard QLabel#StatLabel {{ font-size: 11px; color: {c['txt2']}; text-transform: uppercase; letter-spacing: 1px; }}

QLabel#SectionHeader {{
    font-size: 11px; font-weight: 600; color: {c['txt2']};
    letter-spacing: 2px; text-transform: uppercase; padding: 12px 0 6px 0;
}}
QLabel#PageTitle {{ font-size: 22px; font-weight: 700; color: {c['txt0']}; padding-bottom: 4px; }}

#TaskRow {{
    background-color: {c['bg2']};
    border: 1px solid {c['bg4']};
    border-radius: 8px;
    margin: 3px 0;
    padding: 12px 14px;
}}
#TaskRow:hover {{ border-color: {c['acc']}; }}
#TaskRow[attention="1"] {{ border-left: 3px solid {c['hi']}; }}
#TaskRow[attention="2"] {{ border-left: 3px solid {c['warn']}; }}
#TaskRow[attention="3"] {{ border-left: 3px solid {c['crit']}; }}

QLabel#TaskTitle {{ font-size: 14px; font-weight: 500; color: {c['txt0']}; }}
QLabel#TaskMeta {{ font-size: 11px; color: {c['txt2']}; }}
QLabel#TaskTitle[completed="true"] {{ color: {c['txt2']}; text-decoration: line-through; }}

QLabel#PriBadge {{ border-radius: 4px; padding: 2px 8px; font-size: 10px; font-weight: 700; letter-spacing: 1px; }}
QLabel#PriBadge[level="critical"] {{ background: {c['crit']}; color: #fff; }}
QLabel#PriBadge[level="high"]     {{ background: {c['warn']}; color: #000; }}
QLabel#PriBadge[level="medium"]   {{ background: {c['acc']}; color: {acc_text}; }}
QLabel#PriBadge[level="low"]      {{ background: {c['bg4']}; color: {c['txt1']}; }}

QPushButton {{
    background-color: {c['bg3']};
    border: 1px solid {c['bg4']};
    border-radius: 6px;
    padding: 7px 16px;
    color: {c['txt0']};
    font-weight: 500;
}}
QPushButton:hover {{ background-color: {c['bg4']}; border-color: {c['acc']}; }}
QPushButton:pressed {{ background-color: {c['bg2']}; }}

QPushButton#PrimaryBtn {{ background-color: {c['acc']}; border-color: {c['acc']}; color: {acc_text}; font-weight: 600; }}
QPushButton#PrimaryBtn:hover {{ background-color: {c['acc2']}; }}

QPushButton#DangerBtn {{ background-color: {c['crit']}; border-color: {c['crit']}; color: #fff; }}
QPushButton#SuccessBtn {{ background-color: {c['ok']}; border-color: {c['ok']}; color: #0D0F12; font-weight: 600; }}
QPushButton#GhostBtn {{ background: transparent; border-color: {c['bg4']}; color: {c['txt1']}; }}
QPushButton#GhostBtn:hover {{ border-color: {c['acc']}; color: {c['txt0']}; }}

QLineEdit, QTextEdit, QPlainTextEdit {{
    background-color: {c['bg2']};
    border: 1px solid {c['bg4']};
    border-radius: 6px;
    padding: 8px 12px;
    color: {c['txt0']};
    selection-background-color: {c['acc']};
}}
QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus {{ border-color: {c['acc']}; }}

QComboBox {{
    background-color: {c['bg2']}; border: 1px solid {c['bg4']};
    border-radius: 6px; padding: 7px 12px; color: {c['txt0']};
}}
QComboBox:hover {{ border-color: {c['acc']}; }}
QComboBox QAbstractItemView {{
    background-color: {c['bg2']}; border: 1px solid {c['acc']};
    selection-background-color: {c['bg3']}; color: {c['txt0']};
}}

QDateTimeEdit, QTimeEdit, QSpinBox, QDoubleSpinBox {{
    background-color: {c['bg2']}; border: 1px solid {c['bg4']};
    border-radius: 6px; padding: 7px 12px; color: {c['txt0']};
}}
QDateTimeEdit:hover, QTimeEdit:hover {{ border-color: {c['acc']}; }}

QScrollBar:vertical {{ background: {c['bg1']}; width: 8px; }}
QScrollBar::handle:vertical {{ background: {c['bg4']}; border-radius: 4px; min-height: 20px; }}
QScrollBar::handle:vertical:hover {{ background: {c['acc']}; }}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}

QScrollBar:horizontal {{ background: {c['bg1']}; height: 8px; }}
QScrollBar::handle:horizontal {{ background: {c['bg4']}; border-radius: 4px; min-width: 20px; }}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width: 0; }}

QTabWidget::pane {{ background: {c['bg2']}; border: 1px solid {c['bg4']}; border-radius: 8px; top: -1px; }}
QTabBar::tab {{ background: transparent; padding: 8px 20px; color: {c['txt1']}; border-bottom: 2px solid transparent; }}
QTabBar::tab:selected {{ color: {c['acc']}; border-bottom: 2px solid {c['acc']}; }}
QTabBar::tab:hover {{ color: {c['txt0']}; }}

QProgressBar {{ background-color: {c['bg3']}; border: none; border-radius: 4px; height: 6px; text-align: center; }}
QProgressBar::chunk {{ background-color: {c['acc']}; border-radius: 4px; }}

QFrame[frameShape="4"], QFrame[frameShape="5"] {{ border: none; background-color: {c['bg4']}; max-height: 1px; }}

QToolTip {{ background-color: {c['bg3']}; color: {c['txt0']}; border: 1px solid {c['acc']}; border-radius: 4px; padding: 4px 8px; }}

#FocusWindow {{ background-color: {c['bg0']}; border: 1px solid {c['acc']}; border-radius: 12px; }}
#FocusTitle {{ font-size: 20px; font-weight: 700; color: {c['acc']}; letter-spacing: 1px; }}

QLabel#AgeWarn {{ color: {c['hi']}; font-size: 10px; font-weight: 600; }}
QLabel#AgeEsc  {{ color: {c['warn']}; font-size: 10px; font-weight: 600; }}
QLabel#AgeAck  {{ color: {c['crit']}; font-size: 10px; font-weight: 600; }}

QCheckBox::indicator {{ width: 16px; height: 16px; border: 2px solid {c['bg4']}; border-radius: 4px; background: {c['bg2']}; }}
QCheckBox::indicator:checked {{ background: {c['acc']}; border-color: {c['acc']}; }}
QCheckBox::indicator:hover {{ border-color: {c['acc']}; }}

#PaletteSwatch {{ border-radius: 8px; border: 2px solid transparent; }}
#PaletteSwatch[selected="true"] {{ border: 2px solid {c['txt0']}; }}
"""


def _is_light(hex_color: str) -> bool:
    hex_color = hex_color.lstrip("#")
    r, g, b = int(hex_color[0:2], 16), int(hex_color[2:4], 16), int(hex_color[4:6], 16)
    luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255
    return luminance > 0.6
