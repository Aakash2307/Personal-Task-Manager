"""Dialog for creating or editing a task."""
from __future__ import annotations
from datetime import datetime
from typing import Optional

from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QLineEdit, QTextEdit, QComboBox, QDateTimeEdit,
    QDoubleSpinBox, QPushButton, QFormLayout, QWidget,
    QDialogButtonBox,
)
from PyQt6.QtCore import Qt, QDateTime

from app.models.task import Task, Priority, Status
from app.services.task_service import TaskService


class TaskEditorDialog(QDialog):
    def __init__(self, service: TaskService, task: Optional[Task] = None, parent=None):
        super().__init__(parent)
        self._service = service
        self._task = task
        self._editing = task is not None
        self.setWindowTitle("Edit Task" if self._editing else "New Task")
        self.setMinimumWidth(460)
        self.setModal(True)
        self._build()
        if self._editing:
            self._populate()

    def _build(self):
        ly = QVBoxLayout(self)
        ly.setSpacing(16)
        ly.setContentsMargins(24, 24, 24, 24)

        heading = QLabel("Edit Task" if self._editing else "New Task")
        heading.setObjectName("PageTitle")
        ly.addWidget(heading)

        form = QFormLayout()
        form.setSpacing(10)
        form.setLabelAlignment(Qt.AlignmentFlag.AlignRight)

        self._title = QLineEdit()
        self._title.setPlaceholderText("Task title…")
        form.addRow("Title *", self._title)

        self._description = QTextEdit()
        self._description.setPlaceholderText("Describe the task…")
        self._description.setFixedHeight(80)
        form.addRow("Description", self._description)

        self._priority = QComboBox()
        for p in Priority:
            self._priority.addItem(p.value.capitalize(), p)
        form.addRow("Priority", self._priority)

        self._status = QComboBox()
        for s in Status:
            self._status.addItem(s.value.replace("_", " ").capitalize(), s)
        form.addRow("Status", self._status)

        self._category = QComboBox()
        self._category.setEditable(True)
        cats = self._service.categories() or ["General", "Work", "Personal", "Health"]
        for c in cats:
            self._category.addItem(c)
        form.addRow("Category", self._category)

        self._due_date = QDateTimeEdit()
        self._due_date.setCalendarPopup(True)
        self._due_date.setDateTime(QDateTime.currentDateTime())
        self._due_date.setDisplayFormat("yyyy-MM-dd HH:mm")
        self._no_due = QComboBox()
        self._no_due.addItems(["Set due date", "No due date"])
        self._no_due.currentIndexChanged.connect(self._toggle_due)
        due_row = QHBoxLayout()
        due_row.addWidget(self._no_due)
        due_row.addWidget(self._due_date)
        form.addRow("Due Date", due_row)

        self._est = QDoubleSpinBox()
        self._est.setRange(0, 9999)
        self._est.setSuffix(" min")
        self._est.setSingleStep(15)
        form.addRow("Est. Time", self._est)

        self._tags = QLineEdit()
        self._tags.setPlaceholderText("comma-separated tags…")
        form.addRow("Tags", self._tags)

        self._notes = QTextEdit()
        self._notes.setPlaceholderText("Notes…")
        self._notes.setFixedHeight(60)
        form.addRow("Notes", self._notes)

        ly.addLayout(form)

        # Buttons
        btns = QHBoxLayout()
        btns.addStretch()
        cancel = QPushButton("Cancel")
        cancel.setObjectName("GhostBtn")
        cancel.clicked.connect(self.reject)
        save = QPushButton("Save Task")
        save.setObjectName("PrimaryBtn")
        save.clicked.connect(self._save)
        btns.addWidget(cancel)
        btns.addWidget(save)
        ly.addLayout(btns)

    def _toggle_due(self, idx: int):
        self._due_date.setVisible(idx == 0)

    def _populate(self):
        t = self._task
        self._title.setText(t.title)
        self._description.setPlainText(t.description or "")
        idx = self._priority.findData(t.priority)
        if idx >= 0:
            self._priority.setCurrentIndex(idx)
        idx = self._status.findData(t.status)
        if idx >= 0:
            self._status.setCurrentIndex(idx)
        self._category.setCurrentText(t.category or "General")
        if t.due_date:
            self._no_due.setCurrentIndex(0)
            self._due_date.setDateTime(
                QDateTime.fromSecsSinceEpoch(int(t.due_date.timestamp()))
            )
        else:
            self._no_due.setCurrentIndex(1)
            self._due_date.setVisible(False)
        if t.estimated_minutes:
            self._est.setValue(t.estimated_minutes)
        if t.tags:
            self._tags.setText(", ".join(tag.name for tag in t.tags))
        self._notes.setPlainText(t.notes or "")

    def _save(self):
        title = self._title.text().strip()
        if not title:
            self._title.setFocus()
            return

        due = None
        if self._no_due.currentIndex() == 0:
            due = self._due_date.dateTime().toPyDateTime()

        tag_names = [t.strip() for t in self._tags.text().split(",") if t.strip()]

        kwargs = dict(
            title=title,
            description=self._description.toPlainText(),
            priority=self._priority.currentData(),
            due_date=due,
            category=self._category.currentText().strip() or "General",
            estimated_minutes=self._est.value() or None,
            tags=tag_names,
            notes=self._notes.toPlainText(),
        )

        if self._editing:
            kwargs["status"] = self._status.currentData()
            self._service.update_task(self._task.id, **kwargs)
        else:
            self._service.create_task(**kwargs)

        self.accept()
