"""
Scheduler that fires signals at user-configured Focus/Planning times,
carry-forward midnight, and weekly backup.
"""
from __future__ import annotations
from datetime import datetime, time, timedelta, date
from PyQt6.QtCore import QObject, QTimer, pyqtSignal

from app.services.settings import SettingsService


class SchedulerService(QObject):
    focus_window_trigger = pyqtSignal()
    planning_window_trigger = pyqtSignal()
    weekly_review_trigger = pyqtSignal()
    carry_forward_trigger = pyqtSignal()
    backup_trigger = pyqtSignal()
    planning_reminder_trigger = pyqtSignal()

    CARRY_TIME = time(0, 1)
    BACKUP_WEEKDAY = 6  # Sunday

    def __init__(self, parent=None):
        super().__init__(parent)
        self._settings = SettingsService.instance()
        self._last_focus_date: date | None = None
        self._last_planning_date: date | None = None
        self._last_carry_date: date | None = None
        self._last_backup_week: int | None = None
        self._planning_done_today = False
        self._planning_reminder_active = False

        self._tick = QTimer(self)
        self._tick.setInterval(15_000)  # check every 15 seconds
        self._tick.timeout.connect(self._check)

        self._planning_reminder = QTimer(self)
        self._planning_reminder.setInterval(30 * 60 * 1000)  # 30 min
        self._planning_reminder.timeout.connect(self._fire_planning_reminder)

    @property
    def focus_time(self) -> time:
        return time(
            self._settings.get("focus_hour", 11),
            self._settings.get("focus_minute", 0),
        )

    @property
    def planning_time(self) -> time:
        return time(
            self._settings.get("planning_hour", 18),
            self._settings.get("planning_minute", 0),
        )

    def reload_settings(self):
        """Call after the user changes Focus/Planning times in Settings.
        Resets today's 'already fired' flags so a new, earlier/later time
        can still fire today if it hasn't passed yet."""
        now_time = datetime.now().time()
        if now_time < self.focus_time:
            self._last_focus_date = None
        if now_time < self.planning_time:
            self._last_planning_date = None

    def start(self):
        self._tick.start()

    def stop(self):
        self._tick.stop()
        self._planning_reminder.stop()

    def mark_planning_done(self):
        self._planning_done_today = True
        self._planning_reminder.stop()
        self._planning_reminder_active = False

    def _check(self):
        now = datetime.now()
        today = now.date()
        current_time = now.time()

        # Focus window
        if (
            self._last_focus_date != today
            and current_time >= self.focus_time
        ):
            self._last_focus_date = today
            self.focus_window_trigger.emit()

        # Planning window (or weekly review on Sunday)
        if (
            self._last_planning_date != today
            and current_time >= self.planning_time
        ):
            self._last_planning_date = today
            self._planning_done_today = False
            if today.weekday() == self.BACKUP_WEEKDAY:
                self.weekly_review_trigger.emit()
            else:
                self.planning_window_trigger.emit()
            if not self._planning_reminder_active:
                self._planning_reminder_active = True
                self._planning_reminder.start()

        # Carry forward at midnight
        if self._last_carry_date != today and current_time >= self.CARRY_TIME:
            self._last_carry_date = today
            self.carry_forward_trigger.emit()

        # Weekly backup on Sunday
        week = today.isocalendar()[1]
        if (
            today.weekday() == self.BACKUP_WEEKDAY
            and self._last_backup_week != week
        ):
            self._last_backup_week = week
            self.backup_trigger.emit()

    def _fire_planning_reminder(self):
        if not self._planning_done_today:
            self.planning_reminder_trigger.emit()
