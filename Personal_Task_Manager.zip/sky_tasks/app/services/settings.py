"""
Simple key-value settings store using a JSON file.
Lives at ~/.local/share/sky_tasks/settings.json
"""
from __future__ import annotations
import json
from pathlib import Path


SETTINGS_PATH = Path.home() / ".local" / "share" / "sky_tasks" / "settings.json"

DEFAULTS = {
    "setup_complete": False,
    "user_name": "Sky",
    "theme_mode": "dark",          # "dark" | "light"
    "palette_id": "sky_blue",      # see app/ui/themes.py PRESET_PALETTES
    "custom_color": None,          # hex string if palette_id == "custom"
    "focus_hour": 11,
    "focus_minute": 0,
    "planning_hour": 18,
    "planning_minute": 0,
}


class SettingsService:
    _instance: "SettingsService | None" = None

    def __init__(self):
        SETTINGS_PATH.parent.mkdir(parents=True, exist_ok=True)
        self._data: dict = {}
        self._load()

    @classmethod
    def instance(cls) -> "SettingsService":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def get(self, key: str, default=None):
        if key in self._data:
            return self._data[key]
        if default is not None:
            return default
        return DEFAULTS.get(key)

    def set(self, key: str, value):
        self._data[key] = value
        self._save()

    def set_many(self, **kwargs):
        self._data.update(kwargs)
        self._save()

    def is_first_run(self) -> bool:
        return not self._data.get("setup_complete", False)

    def _load(self):
        try:
            if SETTINGS_PATH.exists():
                self._data = json.loads(SETTINGS_PATH.read_text())
        except Exception:
            self._data = {}

    def _save(self):
        SETTINGS_PATH.write_text(json.dumps(self._data, indent=2))
