"""
Desktop notification service using libnotify / notify-send on Linux,
with PyQt6 fallback.
"""
from __future__ import annotations
import subprocess
import shutil
from PyQt6.QtWidgets import QSystemTrayIcon


class NotificationService:
    def __init__(self, tray: QSystemTrayIcon | None = None):
        self._tray = tray
        self._has_notify_send = bool(shutil.which("notify-send"))

    def notify(self, title: str, body: str, urgency: str = "normal"):
        """
        urgency: low | normal | critical
        """
        if self._has_notify_send:
            try:
                subprocess.Popen(
                    ["notify-send", "-u", urgency, "-a", "Sky Tasks", title, body],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
                return
            except Exception:
                pass
        # Fallback to system tray balloon
        if self._tray:
            icon_map = {
                "low": QSystemTrayIcon.MessageIcon.Information,
                "normal": QSystemTrayIcon.MessageIcon.Information,
                "critical": QSystemTrayIcon.MessageIcon.Warning,
            }
            self._tray.showMessage(
                title, body, icon_map.get(urgency, QSystemTrayIcon.MessageIcon.Information), 5000
            )
