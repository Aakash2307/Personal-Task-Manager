from __future__ import annotations
from datetime import datetime, date
from typing import List, Optional
from sqlalchemy.orm import Session
from sqlalchemy import or_, and_

from app.models.task import Task, Priority, Status, Tag
from app.database.manager import DatabaseManager


class TaskService:
    """All task CRUD and business logic."""

    def __init__(self):
        self._db = DatabaseManager.instance()

    # ------------------------------------------------------------------ #
    # CRUD
    # ------------------------------------------------------------------ #

    def create_task(
        self,
        title: str,
        description: str = "",
        priority: Priority = Priority.MEDIUM,
        due_date: Optional[datetime] = None,
        category: str = "General",
        estimated_minutes: Optional[float] = None,
        tags: Optional[List[str]] = None,
        notes: str = "",
    ) -> Task:
        with self._db.session() as s:
            task = Task(
                title=title,
                description=description,
                priority=priority,
                status=Status.PENDING,
                due_date=due_date,
                category=category,
                estimated_minutes=estimated_minutes,
                notes=notes,
            )
            if tags:
                task.tags = [self._get_or_create_tag(s, t) for t in tags]
            s.add(task)
            s.commit()
            s.refresh(task)
            return task

    def update_task(self, task_id: int, **kwargs) -> Optional[Task]:
        with self._db.session() as s:
            task = s.get(Task, task_id)
            if not task:
                return None
            if "tags" in kwargs:
                tag_names = kwargs.pop("tags")
                task.tags = [self._get_or_create_tag(s, t) for t in tag_names]
            for k, v in kwargs.items():
                if hasattr(task, k):
                    setattr(task, k, v)
            s.commit()
            s.refresh(task)
            return task

    def delete_task(self, task_id: int) -> bool:
        with self._db.session() as s:
            task = s.get(Task, task_id)
            if not task:
                return False
            s.delete(task)
            s.commit()
            return True

    def get_task(self, task_id: int) -> Optional[Task]:
        with self._db.session() as s:
            task = s.get(Task, task_id)
            if task:
                # Eagerly load tags before session closes
                _ = [t.name for t in task.tags]
                s.expunge(task)
            return task

    def complete_task(self, task_id: int) -> Optional[Task]:
        return self.update_task(
            task_id,
            status=Status.COMPLETED,
            completed_at=datetime.utcnow(),
        )

    def archive_task(self, task_id: int) -> Optional[Task]:
        return self.update_task(task_id, status=Status.ARCHIVED)

    def start_task(self, task_id: int) -> Optional[Task]:
        return self.update_task(task_id, status=Status.IN_PROGRESS)

    def acknowledge_task(self, task_id: int) -> Optional[Task]:
        return self.update_task(task_id, acknowledged=True)

    # ------------------------------------------------------------------ #
    # Queries
    # ------------------------------------------------------------------ #

    def all_tasks(self) -> List[Task]:
        with self._db.session() as s:
            return s.query(Task).filter(
                Task.status != Status.ARCHIVED
            ).order_by(Task.priority, Task.due_date).all()

    def pending_tasks(self) -> List[Task]:
        with self._db.session() as s:
            return s.query(Task).filter(
                Task.status.in_([Status.PENDING, Status.IN_PROGRESS])
            ).all()

    def overdue_tasks(self) -> List[Task]:
        now = datetime.utcnow()
        with self._db.session() as s:
            return s.query(Task).filter(
                Task.due_date < now,
                Task.status.in_([Status.PENDING, Status.IN_PROGRESS]),
            ).order_by(Task.due_date).all()

    def todays_tasks(self) -> List[Task]:
        today = date.today()
        with self._db.session() as s:
            return s.query(Task).filter(
                and_(
                    Task.status.in_([Status.PENDING, Status.IN_PROGRESS]),
                    or_(
                        # Due today
                        and_(
                            Task.due_date != None,
                            Task.due_date >= datetime.combine(today, datetime.min.time()),
                            Task.due_date < datetime.combine(today, datetime.max.time()),
                        ),
                        # Carry-forward (old tasks without due date)
                        Task.carried_forward == True,
                    )
                )
            ).all()

    def critical_tasks(self) -> List[Task]:
        with self._db.session() as s:
            return s.query(Task).filter(
                Task.priority == Priority.CRITICAL,
                Task.status.in_([Status.PENDING, Status.IN_PROGRESS]),
            ).all()

    def completed_today(self) -> List[Task]:
        today = date.today()
        with self._db.session() as s:
            return s.query(Task).filter(
                Task.status == Status.COMPLETED,
                Task.completed_at >= datetime.combine(today, datetime.min.time()),
                Task.completed_at < datetime.combine(today, datetime.max.time()),
            ).all()

    def completed_this_week(self) -> List[Task]:
        from datetime import timedelta
        start = datetime.combine(date.today(), datetime.min.time())
        start -= timedelta(days=start.weekday())
        with self._db.session() as s:
            return s.query(Task).filter(
                Task.status == Status.COMPLETED,
                Task.completed_at >= start,
            ).all()

    def completed_this_month(self) -> List[Task]:
        today = date.today()
        start = datetime(today.year, today.month, 1)
        with self._db.session() as s:
            return s.query(Task).filter(
                Task.status == Status.COMPLETED,
                Task.completed_at >= start,
            ).all()

    def search(
        self,
        query: str = "",
        priority: Optional[Priority] = None,
        status: Optional[Status] = None,
        category: Optional[str] = None,
    ) -> List[Task]:
        with self._db.session() as s:
            q = s.query(Task)
            if query:
                like = f"%{query}%"
                q = q.filter(
                    or_(Task.title.ilike(like), Task.description.ilike(like))
                )
            if priority:
                q = q.filter(Task.priority == priority)
            if status:
                q = q.filter(Task.status == status)
            if category:
                q = q.filter(Task.category == category)
            return q.order_by(Task.priority, Task.due_date).all()

    def attention_tasks(self) -> List[Task]:
        """Tasks requiring escalated attention (age >= 3 days)."""
        with self._db.session() as s:
            tasks = s.query(Task).filter(
                Task.status.in_([Status.PENDING, Status.IN_PROGRESS])
            ).all()
            return [t for t in tasks if t.attention_level >= 1]

    def tasks_requiring_ack(self) -> List[Task]:
        with self._db.session() as s:
            tasks = s.query(Task).filter(
                Task.status.in_([Status.PENDING, Status.IN_PROGRESS]),
                Task.acknowledged == False,
            ).all()
            return [t for t in tasks if t.attention_level == 3]

    def carry_forward_tasks(self):
        """Mark all unfinished tasks as carried forward (run at midnight)."""
        with self._db.session() as s:
            tasks = s.query(Task).filter(
                Task.status.in_([Status.PENDING, Status.IN_PROGRESS])
            ).all()
            for t in tasks:
                t.carried_forward = True
                t.carry_count = (t.carry_count or 0) + 1
            s.commit()

    def stats(self) -> dict:
        total = len(self.all_tasks())
        c_today = len(self.completed_today())
        c_week = len(self.completed_this_week())
        c_month = len(self.completed_this_month())
        pending = len(self.pending_tasks())
        overdue = len(self.overdue_tasks())

        # Average completion time
        with self._db.session() as s:
            completed = s.query(Task).filter(
                Task.status == Status.COMPLETED,
                Task.completed_at != None,
            ).all()
            if completed:
                deltas = [
                    (t.completed_at - t.created_at).total_seconds() / 3600
                    for t in completed
                ]
                avg_hours = sum(deltas) / len(deltas)
            else:
                avg_hours = 0.0

        rate = (c_month / max(c_month + pending, 1)) * 100

        return {
            "total": total,
            "pending": pending,
            "overdue": overdue,
            "completed_today": c_today,
            "completed_week": c_week,
            "completed_month": c_month,
            "completion_rate": round(rate, 1),
            "avg_completion_hours": round(avg_hours, 1),
        }

    def categories(self) -> List[str]:
        with self._db.session() as s:
            rows = s.query(Task.category).distinct().all()
            return sorted(set(r[0] for r in rows if r[0]))

    # ------------------------------------------------------------------ #
    # Internals
    # ------------------------------------------------------------------ #

    def _get_or_create_tag(self, session: Session, name: str) -> Tag:
        tag = session.query(Tag).filter_by(name=name).first()
        if not tag:
            tag = Tag(name=name)
            session.add(tag)
        return tag
