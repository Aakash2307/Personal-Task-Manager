import os
import shutil
from datetime import datetime
from pathlib import Path
from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker, Session
from app.database.base import Base


def _get_db_path() -> Path:
    data_dir = Path.home() / ".local" / "share" / "sky_tasks"
    data_dir.mkdir(parents=True, exist_ok=True)
    return data_dir / "sky_tasks.db"


def _get_backup_dir() -> Path:
    backup_dir = Path.home() / ".local" / "share" / "sky_tasks" / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    return backup_dir


class DatabaseManager:
    _instance: "DatabaseManager | None" = None

    def __init__(self):
        self.db_path = _get_db_path()
        self.engine = create_engine(
            f"sqlite:///{self.db_path}",
            echo=False,
            connect_args={"check_same_thread": False},
        )
        # Enable WAL mode for better concurrency
        @event.listens_for(self.engine, "connect")
        def set_wal(dbapi_conn, _):
            dbapi_conn.execute("PRAGMA journal_mode=WAL")
            dbapi_conn.execute("PRAGMA foreign_keys=ON")

        self._SessionFactory = sessionmaker(bind=self.engine, expire_on_commit=False)
        self._init_schema()

    @classmethod
    def instance(cls) -> "DatabaseManager":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def _init_schema(self):
        from app.models import Task, Tag  # noqa: F401 – registers models
        Base.metadata.create_all(self.engine)

    def session(self) -> Session:
        return self._SessionFactory()

    def backup(self):
        backup_dir = _get_backup_dir()
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        dest = backup_dir / f"sky_tasks_backup_{stamp}.db"
        shutil.copy2(self.db_path, dest)
        # Keep only last 8 backups
        backups = sorted(backup_dir.glob("sky_tasks_backup_*.db"))
        for old in backups[:-8]:
            old.unlink(missing_ok=True)
        return dest
