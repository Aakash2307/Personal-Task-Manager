"""Utilities: autostart, paths, etc."""
from __future__ import annotations
import os
import sys
from pathlib import Path


AUTOSTART_DIR = Path.home() / ".config" / "autostart"
AUTOSTART_FILE = AUTOSTART_DIR / "sky_tasks.desktop"

DESKTOP_ENTRY = """\
[Desktop Entry]
Type=Application
Name=Sky Tasks
Comment=Persistent task execution system
Exec={exec_path}
Icon=utilities-reminder
Terminal=false
X-GNOME-Autostart-enabled=true
"""


def install_autostart() -> bool:
    try:
        exec_path = sys.executable + " " + str(Path(__file__).parent.parent.parent / "main.py")
        AUTOSTART_DIR.mkdir(parents=True, exist_ok=True)
        AUTOSTART_FILE.write_text(DESKTOP_ENTRY.format(exec_path=exec_path))
        return True
    except Exception:
        return False


def remove_autostart() -> bool:
    try:
        AUTOSTART_FILE.unlink(missing_ok=True)
        return True
    except Exception:
        return False


def autostart_enabled() -> bool:
    return AUTOSTART_FILE.exists()
