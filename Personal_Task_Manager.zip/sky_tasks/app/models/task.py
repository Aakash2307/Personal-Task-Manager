import enum
from datetime import datetime
from sqlalchemy import (
    Column, Integer, String, Text, DateTime,
    Enum, Boolean, Float, ForeignKey, Table
)
from sqlalchemy.orm import relationship
from app.database.base import Base


class Priority(enum.Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class Status(enum.Enum):
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    ARCHIVED = "archived"


TaskTag = Table(
    "task_tags",
    Base.metadata,
    Column("task_id", Integer, ForeignKey("tasks.id"), primary_key=True),
    Column("tag_id", Integer, ForeignKey("tags.id"), primary_key=True),
)


class Tag(Base):
    __tablename__ = "tags"

    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(64), unique=True, nullable=False)
    color = Column(String(7), default="#6C8EBF")

    tasks = relationship("Task", secondary=TaskTag, back_populates="tags")

    def __repr__(self):
        return f"<Tag(id={self.id}, name={self.name!r})>"


class Task(Base):
    __tablename__ = "tasks"

    id = Column(Integer, primary_key=True, autoincrement=True)
    title = Column(String(256), nullable=False)
    description = Column(Text, default="")
    priority = Column(Enum(Priority), default=Priority.MEDIUM, nullable=False)
    status = Column(Enum(Status), default=Status.PENDING, nullable=False)
    category = Column(String(128), default="General")

    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    due_date = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)

    estimated_minutes = Column(Float, nullable=True)
    actual_minutes = Column(Float, nullable=True)

    acknowledgement_required = Column(Boolean, default=False)
    acknowledged = Column(Boolean, default=False)
    carried_forward = Column(Boolean, default=False)
    carry_count = Column(Integer, default=0)

    notes = Column(Text, default="")

    tags = relationship("Tag", secondary=TaskTag, back_populates="tasks")

    @property
    def days_overdue(self) -> int:
        if self.due_date and self.status not in (Status.COMPLETED, Status.ARCHIVED):
            delta = datetime.utcnow() - self.due_date
            return max(0, delta.days)
        return 0

    @property
    def age_days(self) -> int:
        return (datetime.utcnow() - self.created_at).days

    @property
    def attention_level(self) -> int:
        """0=normal, 1=highlight, 2=warning, 3=require_ack"""
        if self.status in (Status.COMPLETED, Status.ARCHIVED):
            return 0
        age = self.age_days
        if age >= 14:
            return 3
        if age >= 7:
            return 2
        if age >= 3:
            return 1
        return 0

    @property
    def is_overdue(self) -> bool:
        if self.due_date and self.status not in (Status.COMPLETED, Status.ARCHIVED):
            return datetime.utcnow() > self.due_date
        return False

    @property
    def is_due_today(self) -> bool:
        if self.due_date:
            now = datetime.utcnow()
            return self.due_date.date() == now.date()
        return False

    def __repr__(self):
        return f"<Task(id={self.id}, title={self.title!r}, status={self.status})>"
