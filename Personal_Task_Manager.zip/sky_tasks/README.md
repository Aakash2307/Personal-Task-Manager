# Sky Tasks

**A persistent task execution system for Ubuntu.**  
Not a to-do list. Tasks never disappear until they are done.

---

## What it does

- Tasks carry forward every day until completed — nothing is forgotten
- 11 AM **Focus Window** shows overdue, critical, and carry-forward tasks
- 6 PM **Planning Window** lets you set up tomorrow; reminds every 30 min until done or skipped
- Sunday 6 PM **Weekly Review** with productivity trends
- Escalating attention system: 3 days → highlighted, 7 days → warning, 14 days → acknowledgement required
- System tray icon — always running
- Weekly automatic database backup

---

## Project Structure

```
sky_tasks/
├── main.py                     # Entry point
├── requirements.txt
├── install.sh
├── sky_tasks.spec              # PyInstaller packaging
└── app/
    ├── models/
    │   └── task.py             # Task, Tag, Priority, Status
    ├── database/
    │   ├── base.py             # SQLAlchemy declarative base
    │   └── manager.py          # DB init, sessions, backups
    ├── services/
    │   ├── task_service.py     # All business logic & queries
    │   ├── scheduler.py        # Timed event signals (11am/6pm)
    │   └── notification.py     # notify-send + tray fallback
    ├── ui/
    │   ├── styles.py           # Dark mode QSS stylesheet
    │   ├── widgets.py          # TaskRow, StatCard, badges
    │   ├── main_window.py      # Sidebar + stack + tray
    │   ├── dashboard.py        # Main dashboard
    │   ├── tasks_view.py       # Full task list + search/filter
    │   ├── stats_view.py       # Statistics panel
    │   ├── task_editor.py      # Create/edit dialog
    │   ├── focus_window.py     # 11 AM focus window
    │   ├── planning_window.py  # 6 PM planning window
    │   └── weekly_review.py    # Sunday review window
    └── utils/
        └── autostart.py        # XDG autostart helper
```

---

## Database Schema

**tasks**
| Column | Type | Notes |
|---|---|---|
| id | INTEGER PK | |
| title | VARCHAR(256) | required |
| description | TEXT | |
| priority | ENUM | critical/high/medium/low |
| status | ENUM | pending/in_progress/completed/archived |
| category | VARCHAR(128) | |
| created_at | DATETIME | auto |
| due_date | DATETIME | nullable |
| completed_at | DATETIME | nullable |
| estimated_minutes | FLOAT | nullable |
| actual_minutes | FLOAT | nullable |
| acknowledgement_required | BOOLEAN | |
| acknowledged | BOOLEAN | |
| carried_forward | BOOLEAN | set at midnight |
| carry_count | INTEGER | increments each carry |
| notes | TEXT | |

**tags** → id, name, color  
**task_tags** → task_id, tag_id (many-to-many)

---

## Installation

### Quick start (Ubuntu 22.04+)

```bash
git clone <repo>
cd sky_tasks
bash install.sh
source .venv/bin/activate
python main.py
```

### Enable autostart on login

```bash
source .venv/bin/activate
python -c "from app.utils.autostart import install_autostart; install_autostart()"
```

This creates `~/.config/autostart/sky_tasks.desktop`.

### Dependencies

```
PyQt6>=6.6.0
SQLAlchemy>=2.0.0
alembic>=1.13.0
python-dateutil>=2.8.2
```

Desktop notifications use `notify-send` (pre-installed on most Ubuntu systems).

---

## Keyboard Shortcuts

| Shortcut | Action |
|---|---|
| Ctrl+1 | Dashboard |
| Ctrl+2 | Tasks |
| Ctrl+3 | Statistics |
| Ctrl+N | New Task |

---

## Packaging with PyInstaller

```bash
source .venv/bin/activate
pip install pyinstaller
pyinstaller sky_tasks.spec
# Output: dist/sky_tasks (single executable)
```

---

## Future Extension Architecture

The codebase is structured for clean extension:

- **`app/services/`** — add new service classes (e.g., `obsidian_service.py`, `gcal_service.py`)
- **`app/ui/`** — add new views; register in `MainWindow._build_ui()`
- **Scheduler** — add new `pyqtSignal` + time check in `SchedulerService._check()`
- **TaskService** — queries are isolated; easy to swap out or extend

Planned integration hooks:
- **Obsidian** — export tasks as markdown to vault directory
- **Google Calendar** — `googleapiclient` + OAuth stored locally
- **Local LLMs** — `ollama` HTTP client for AI prioritization
- **Voice commands** — `speech_recognition` → task creation pipeline

---

## Data Location

- Database: `~/.local/share/sky_tasks/sky_tasks.db`
- Backups: `~/.local/share/sky_tasks/backups/` (last 8 weekly backups kept)
- Autostart: `~/.config/autostart/sky_tasks.desktop`
