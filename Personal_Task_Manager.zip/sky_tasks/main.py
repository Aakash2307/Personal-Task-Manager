#!/usr/bin/env python3
"""Sky Tasks – entry point."""
import sys
import os

# Ensure project root is in path when run directly
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from PyQt6.QtWidgets import QApplication
from PyQt6.QtGui import QFont

from app.ui.themes import generate_stylesheet
from app.services.settings import SettingsService


def apply_theme(app: QApplication):
    """Read current theme settings and apply the generated stylesheet."""
    settings = SettingsService.instance()
    mode = settings.get("theme_mode", "dark")
    palette_id = settings.get("palette_id", "sky_blue")
    custom_hex = settings.get("custom_color")
    app.setStyleSheet(generate_stylesheet(mode=mode, palette_id=palette_id, custom_hex=custom_hex))


def main():
    os.environ.setdefault("QT_AUTO_SCREEN_SCALE_FACTOR", "1")

    app = QApplication(sys.argv)
    app.setApplicationName("Sky Tasks")
    app.setApplicationVersion("1.0.0")
    app.setOrganizationName("SkyTasks")
    app.setQuitOnLastWindowClosed(False)

    font = QFont("Inter", 13)
    font.setHintingPreference(QFont.HintingPreference.PreferFullHinting)
    app.setFont(font)

    # Apply a default theme immediately so the setup dialog itself looks right
    apply_theme(app)

    # First-run setup wizard
    settings = SettingsService.instance()
    if settings.is_first_run():
        from app.ui.setup_dialog import SetupDialog
        setup = SetupDialog()
        if setup.exec() != SetupDialog.DialogCode.Accepted:
            sys.exit(0)
        # Re-apply theme since setup may have changed it
        apply_theme(app)

    from app.ui.main_window import MainWindow
    window = MainWindow(apply_theme_callback=lambda: apply_theme(app))
    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
